<?php

use App\SecQuestion;
use Faker\Generator as Faker;

$factory->define(SecQuestion::class, function (Faker $faker) {
    return [
        'question' => $faker->sentence($nbWords = 6, $variableNbWords = true),
        'status' => 1
    ];
});
