<?php

use Illuminate\Database\Seeder;

class SecQuestionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $sec_qs = factory(\App\SecQuestion::class, 5)->create();
    }
}
