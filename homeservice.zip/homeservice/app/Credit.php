<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Credit extends Model
{
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'user_id', 'card_no', 'exp_month', 'exp_year', 'cvv', 'name_on_card', 'balance'
    ];    

    protected $primaryKey = 'id';

    public function user()
    {
        return $this->belongsTo('App\User');
    }
}