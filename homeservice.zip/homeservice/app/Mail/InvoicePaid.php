<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class InvoicePaid extends Mailable
{
    use Queueable, SerializesModels;

    protected $user;
    protected $invoice;
    protected $order;
    protected $serviceItem;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(\App\User $user, $invoice, $serviceItem)
    {
        $this->user = $user;
        $this->invoice = $invoice;
        $this->serviceItem = $serviceItem;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->markdown('emails.invoice-paid')
                    ->subject('Invoice for order #' . $this->serviceItem->id . ' has been paid')
                    ->with([
                            'name' => $this->user->name,
                            'invoice' => $this->invoice,
                            'service' => $this->serviceItem
                        ]);
    }
}
