<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;
use Session;
use Illuminate\Support\ViewErrorBag;
use App\Mail\LeaveApproved;
use App\Mail\InvoicePaid;
use App\Mail\PaymentReceived;
use App\Mail\ServiceCancelled;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use DateTime;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function showChangePasswordForm(){
        return view('auth.changepassword');
    }

    public function changePassword(Request $request){
        if (!(Hash::check($request->get('current-password'), Auth::user()->password))) {
            // The passwords matches
            return redirect()->back()->with("error","Your current password does not matches with the password you provided. Please try again.");
        }
        if(strcmp($request->get('current-password'), $request->get('new-password')) == 0){
            //Current password and new password are same
            return redirect()->back()->with("error","New Password cannot be same as your current password. Please choose a different password.");
        }
        $validatedData = $request->validate([
            'current-password' => 'required',
            'new-password' => 'required|string|min:6|confirmed',
        ]);
        //Change Password
        $user = Auth::user();
        $user->password = bcrypt($request->get('new-password'));
        $user->save();
        return redirect()->back()->with("success","Password changed successfully !");
    }

    public function showEditProfileForm() {
        $userInfo = \App\UserInformation::where('user_id', Auth::user()->id)->first();

        $districts = \App\District::where('status', 1)->orderBy('id')->pluck('district', 'id');
        $sec_qs = \App\SecQuestion::where('status', 1)->orderBy('id')->pluck('question', 'id');
        $categories = \App\ServiceCategory::where('status', 1)->orderBy('id')->pluck('category', 'id');
        return view('user.profile', ['userInfo' => $userInfo, 'districts' => $districts, 'sec_qs' => $sec_qs, 'categories' => $categories, 'customer' => Auth::user()->hasRole('customer'), 'worker' => Auth::user()->hasRole('worker')]);
    }

    public function editProfile(Request $request) {
        $userInf = \App\UserInformation::where('user_id', Auth::user()->id)->first();

        $fields = array(
                    'name' => ['required', 'string', 'max:191', 'alpha_spaces'],
                    'addr' => ['required', 'string', 'max:191'],
                    'did' => 'required',
                    'pin_code' => 'required|numeric|between:600000,699999',
                    'phone' => ['required', 'numeric', 'between:6000000000,9999999999'],
                    'sec_q' => 'required',
                    'sec_a' => ['required', 'string', 'max:191']);
        if(isset($request['image']) && !is_null($request['image'])) {
            $fields['image'] = 'mimes:jpg,jpeg,png';
        }

        if(!is_null($request['alt_phone'])) {
            $fields['alt_phone'] = ['numeric', 'between:6000000000,9999999999'];
        }       

        if(Auth::user()->hasRole('worker') == '2') {            
            $fields['scat'] = 'required';
            $fields['per_hour_amount'] = ['required', 'digits_between:1,4'];
            if(isset($request['exp_proof']) && !is_null($request['exp_proof']))
                $fields['exp_proof'] = 'required|mimes:jpg,jpeg,png';
            if(isset($request['id_proof']) && !is_null($request['id_proof']))
                $fields['id_proof'] = 'required|mimes:jpg,jpeg,png';
        }
        
        //var_dump($request);die;
        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if ($validator->fails()) 
            return redirect('edit-profile')
                        ->withErrors($validator)
                        ->withInput();

        $imageName = ''; $expProof = ''; $idProof = ''; $sCat = null; $perHourAmt = 0;

        $user = Auth::user();
        $user->name = $request['name'];
        $user->save();
        
        $userInf->addr = $request['addr'];
        $userInf->district_id = $request['did'];
        $userInf->pin_code = $request['pin_code'];
        $userInf->phone = $request['phone'];
        $userInf->alt_phone = $request['alt_phone'];
        $userInf->sec_q = $request['sec_q'];
        $userInf->sec_a = $request['sec_a'];

        if(!is_null($request['image'])) {
            $imageName = 'p' . time() . '.' . $request['image']->getClientOriginalExtension();

            $request['image']->move(
                base_path() . '/public/images/profile/', $imageName
            );
            $userInf->img = $imageName;
        }
        if(Auth::user()->hasRole('worker')) {
            $perHourAmt = $request['per_hour_amount'];
            $sCat = $request['scat'];

            if(isset($request['exp_proof']) && !is_null($request['exp_proof'])) {
                $expProof = 'e' . time() . '.' . $request['exp_proof']->getClientOriginalExtension();

                $request['exp_proof']->move(
                    base_path() . '/public/images/proofs/', $expProof
                );
                $userInf->exp_proof = $expProof;
            }

            if(isset($request['id_proof']) && !is_null($request['id_proof'])) {
                $idProof = 'a' . time() . '.' . $request['id_proof']->getClientOriginalExtension();

                $request['id_proof']->move(
                    base_path() . '/public/images/proofs/', $idProof
                );                
                $userInf->id_proof = $idProof;
            }
        }
        $userInf->per_hour_amount = $perHourAmt;
        $userInf->service_category = $sCat;
        
        $userInf->save();

        return redirect('edit-profile')->with("success","Profie updated successfully !");
    }

    public function myProfile() {
        $userInfo = \App\UserInformation::where('user_id', Auth::user()->id)->first();
        return view('user.my-profile', ['userInfo' => $userInfo, 'customer' => Auth::user()->hasRole('customer'), 'worker' => Auth::user()->hasRole('worker')]);
    }

    public function orders(Request $request) {        
        if(Auth::user()->hasRole('admin')) {
            $orders = \App\Order::select('orders.*');

            if(!is_null($request->input('type')) && !is_null($request->input('status'))) {
                $orders = $orders->join('order_items', function($join) use($request)
                                             {
                                               $join->on('order_items.order_id', '=', 'orders.id');
                                               if($request->type != '0')
                                                $join->where('order_items.item_type', $request->type);
                                               if($request->status != '11')
                                                $join->where('order_items.status', $request->status);
                                             })
                                        ->orderBy('orders.created_at', 'desc')
                                        ->paginate(config('app.per_page'));
            } elseif(!is_null($request->input('type'))) {
                $orders = $orders->join('order_items', function($join) use($request)
                                             {
                                               $join->on('order_items.order_id', '=', 'orders.id');
                                               if($request->type != '0')
                                                $join->where('order_items.item_type', $request->type);
                                             })
                                        ->orderBy('orders.created_at', 'desc')
                                        ->paginate(config('app.per_page'));
            } elseif(!is_null($request->input('status'))) {
                $orders = $orders->join('order_items', function($join) use($request)
                                             {
                                               $join->on('order_items.order_id', '=', 'orders.id');
                                               if($request->status != '11')
                                                $join->where('order_items.status', $request->status);
                                             })
                                        ->orderBy('orders.created_at', 'desc')
                                        ->paginate(config('app.per_page'));
            } else {
                $orders = \App\Order::orderBy('created_at', 'desc')
                                ->paginate(config('app.per_page'));
            }
        } else
            $orders = \App\Order::where('user_id', Auth::user()->id)
                                ->orderBy('created_at', 'desc')
                                ->paginate(config('app.per_page'));
        return view('orders', ['orders' => $orders, 'type' => $request->type, 'status' => $request->status]);
    }

    public function orderDetails($orderId, Request $request) {
        if(Auth::user()->hasRole('admin'))
            $order = \App\Order::findOrFail($orderId);
        else
            $order = \App\Order::where('user_id', Auth::user()->id)->findOrFail($orderId);

        $orderItems = $order->orderItems->sortBy('item_type');
        $prods = []; $servs = [];
        foreach ($orderItems as $key => $value) {
            if($value->item_type == 1)
                array_push($prods, $value);
            else
                array_push($servs, $value);
        }

        if($request->session()->pull('orderId')) {
            $msg = 'Your order is placed successfully.';
        } else
            $msg = null;

        $prodStatuses = [
                            1 => 'Order Placed',
                            2 => 'Shipped',
                            3 => 'Delivered',
                            6 => 'Cancelled',
                        ];
        $servStatuses = [
                            0 => 'Worker notification sent',
                            1 => 'Order Placed',
                            4 => 'Invoice generated',
                            5 => 'Completed',
                            6 => 'Cancelled',
                            7 => 'Worker confirmed order',
                            8 => 'User requested refund',
                            9 => 'Worker requested payment',
                            10 => 'Refunded',
                            11 => 'Refunded from deposit'
                        ];
        $cardTypes = \App\Credit::distinct()->pluck('type', 'type');

        return view('order-details', ['order' => $order, 'prods' => $prods, 'servs' => $servs, 'msg' => $msg, 'prodStatuses' => $prodStatuses, 'servStatuses' => $servStatuses, 'cardTypes' => $cardTypes]);
    }

    public function payInvoice(Request $request) {
        $fields = [
                    'cardName' => ['required', 'string', 'max:191', 'alpha_spaces'],
                    'cardNumber' => 'required|numeric|between:1000000000000000,9999999999999999',
                    'expiry' => 'required|card_expiry',
                    'cvv' => 'required|numeric|between:100,999'];

        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if ($validator->fails()) 
            return redirect()
                        ->back()
                        ->withErrors($validator)
                        ->withInput();
        
        if(!is_null($request->_invoice)) {
            $invoice = \App\ServiceInvoice::find($request->_invoice);
            $serviceItem = \App\OrderItem::find($invoice->item_id);
            $total = $serviceItem->amount + $invoice->commision - $serviceItem->commision;
        } else {
            $serviceItem = \App\OrderItem::find($request->_item);
            $total = $serviceItem->commision;
        }        

        $balance = \App\Credit::where('user_id', Auth::user()->id)
                                //->where('name_on_card', $request->cardName)
                                ->where('card_no', $request->cardNumber)
                                //->where('expiry', $request->expiry)
                                //->where('cvv', $request->cvv)
                                //->where('type', $request->cardType)
                                ->first();
        if(!is_null($balance)) {
            if($balance->name_on_card != $request->cardName || $balance->expiry != $request->expiry || $balance->cvv != $request->cvv || $balance->type != $request->cardType)
                return redirect()->back()->withErrors(['msg' => 'Card details were not found, please enter valid card details.'])->withInput();
            elseif($balance->balance < $total)
                return redirect()->back()->withErrors(['msg' => 'Sorry! Your account does not have the necessary balance. Available amount, '.config('app.currency').$balance->balance])->withInput();
        } else {
            $balance = new \App\Credit;
            $balance->user_id = Auth::user()->id;
            $balance->card_no = $request->cardNumber;
            $balance->expiry = $request->expiry;
            $balance->cvv = $request->cvv;
            $balance->name_on_card = $request->cardName;
            $balance->type = $request->cardType;
            $balance->balance = 10000;
            $balance->save();
        }        

        if(!is_null($request->_invoice)) {
            $user = \App\User::find($serviceItem->item_id);
            Mail::to($user)->send(new InvoicePaid(Auth::user(), $invoice, $serviceItem));

            $balance->balance -= $total;
            $balance->save();

            //Commision
            $admin = \App\Setting::find('3');
            $adminBalance = \App\Credit::where('user_id', $admin->value)->first();
            $adminBalance->balance += $invoice->commision;
            $adminBalance->save();
            //Worker pay
            $workerBalance = \App\Credit::where('user_id', $serviceItem->item_id)->first();
            if($workerBalance) {
                $workerBalance->balance += ($total - $invoice->commision);
                $workerBalance->save();
            }

            $serviceItem->status = 5;
            $serviceItem->save();
        } else {
            $user = \App\User::find($serviceItem->item_id);
            Mail::to($user)->send(new PaymentReceived($user, $serviceItem));

            $balance->balance -= $total;
            $balance->save();

            //Commision
            $admin = \App\Setting::find('3');
            $adminBalance = \App\Credit::where('user_id', $admin->value)->first();
            $adminBalance->balance += $serviceItem->commision;
            $adminBalance->save();
            
            //Worker pay            
            /*$workerBalance = \App\Credit::where('user_id', Auth::user()->id)->first();
            if($workerBalance) {
                $workerBalance->balance += ($serviceItem->total - $serviceItem->commision);
                $workerBalance->save();
            }*/

            $serviceItem->status = 1;
            $serviceItem->save();
        }

        return redirect()->back()->with("success", "Invoice payment is successful.");
    }

    public static function canRequestRefund($serviceOrder) {
        $endDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $serviceOrder->service_slot_to);
        $now = DateTime::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));
        if($serviceOrder->status == 1 && $endDateTime < $now)
            return true;
        else
            return false;
    }

    public function leaveReview(Request $request) {
        if(!is_null($request->itemId)) {
            $rating = new \App\Review;
            $rating->user_id = Auth::user()->id;
            $rating->item_id = $request->itemId;
            $rating->product_id = $request->productId;
            $rating->worker_id = $request->workerId;
            $rating->rating = $request->rating;
            $rating->comment = $request->comment;
            $rating->save();

            return redirect()->back()->with("success","Your rating has been saved successfully.");
        }
    }

    public static function alreadyReviewed($itemId) {
        $ifExists = \App\Review::where('item_id', $itemId)->get();
        return $ifExists->isEmpty();
    }

    public static function canCancelLeave($leave) { 
        if((new DateTime($leave->from) > new DateTime(date('Y-m-d'))) && ($leave->status == 1))
            return true;
    }

    public function leaves() {
        $user = Auth::user();
        if($user->hasRole('customer'))
            abort(403);

        \App\Leave::where('user_id', Auth::user()->id)
                    ->whereDate('from', '<=', date('Y-m-d'))
                    ->update([
                        'status' => 4
                        ]);
        
        if($user->hasRole('admin'))
            $leaves = \App\Leave::orderBy('created_at', 'desc')
                                    ->orderBy('status', 'desc')
                                    ->paginate(config('app.per_page'));
        else 
            $leaves = $user->leaves()
                            ->orderBy('created_at', 'desc')
                            ->orderBy('status', 'desc')
                            ->paginate(config('app.per_page'));

        $status = [
                    1 => 'Pending approval',
                    2 => 'Approved',
                    3 => 'Declined',
                    4 => 'Cancelled'
                    ];

        $stat = Session::get('message');
        if($stat)
            Session::flash('success', 'Leave application saved successfully !'); 
        return view('leaves', ['leaves' => $leaves, 'status' => $status]);
    }

    public function applyLeave(Request $request) {
        $fields = [
                    'from' => ['required', 'date', 'date_format:d-m-Y'],
                    'to' => ['required', 'date', 'date_format:d-m-Y', 'after_or_equal:from'],
                    'reason' => 'required|alpha_spaces'];

        $validator = Validator::make($request->all(), $fields, [], $this->attributes());
        $ifApplied = \App\Leave::where(function ($query) use ($request) {
                                    $query->whereBetween('from', [join('-', array_reverse( explode('-', $request->from))), join('-', array_reverse( explode('-', $request->to)))])
                                    ->orWhereBetween('to', [join('-', array_reverse( explode('-', $request->from))), join('-', array_reverse( explode('-', $request->to)))]);
                                })
                                ->where('user_id', Auth::user()->id)
                                //->toSql();var_dump($ifApplied, Auth::user()->id);die;
                                ->first();

        //Annual check
        $max = \App\Setting::find('1');
        $leaveCount = \App\Leave::select(DB::raw('sum(datediff(`to`, `from`) + 1) as count'))
                                    ->where('status', 2)
                                    ->where('user_id', Auth::user()->id)
                                    ->whereYear('from', date('Y'))
                                    ->whereYear('to', date('Y'))
                                    //->toSql();var_dump($leaveCount);die;
                                    ->first();

        //Service booked
        $slotFrom = join('-', array_reverse( explode('-', $request->from)));
        $slotTo = join('-', array_reverse( explode('-', $request->to)));
        $servBooked = \App\OrderItem::WhereRaw('(
                        (date(order_items.service_slot_from) >= ? and date(order_items.service_slot_from) <= ?) or 
                        (date(order_items.service_slot_to) >= ? and  date(order_items.service_slot_to) <= ?))', [$slotFrom, $slotTo, $slotFrom, $slotTo])
                                    ->whereIn('status', [7, 1])
                                    //->toSql();var_dump($servBooked);die;
                                    ->get();
        if(new DateTime(join('-', array_reverse( explode('-', $request->to)))) < new DateTime(join('-', array_reverse( explode('-', $request->from))))) 
            return redirect()->back()->withErrors(['msg' => 'Ending date cannot be less than starting date!'])->withInput();

        if((date_diff(new DateTime(join('-', array_reverse( explode('-', $request->to)))), new DateTime(join('-', array_reverse( explode('-', $request->from)))))->days + 1 + $leaveCount->count) > $max->value) {
            return redirect()->back()->withErrors(['msg' => 'You have exhausted available leaves. Available leaves: ' . ($max->value - $leaveCount->count)])->withInput();
        }

        if(!is_null($ifApplied)) {
            return redirect()->back()->withErrors(['msg' => 'You have already applied for leave for the given duration.'])->withInput();
        }

        if($servBooked->count()) {
            return redirect()->back()->withErrors(['msg' => 'You have pending work for the selected day.'])->withInput();
        }

        if ($validator->fails()) 
            return redirect('leaves')
                        ->withErrors($validator)
                        ->withInput();

        $leave = new \App\Leave;
        $leave->user_id = Auth::user()->id;
        $leave->from = join('-', array_reverse( explode('-', $request->from)));
        $leave->to = join('-', array_reverse( explode('-', $request->to)));
        $leave->reason = $request->reason;

        $leave->save();

        return redirect()->back()->with('success','Leave application has been sent successfully!');
    }

    public function toggle($id, Request $request) {
        $leave = \App\Leave::find($id);
        $user = \App\User::find($leave->user_id);

        if($request->input('action') == 'Approve') {
            $leave->status = 2;

            Mail::to($user)->send(new LeaveApproved($user, 1, date('d-m-Y', strtotime($leave->from)) . ' - ' . date('d-m-Y', strtotime($leave->to))));
        } else {
            $leave->status = 3;

            Mail::to($user)->send(new LeaveApproved($user, 0, date('d-m-Y', strtotime($leave->from)) . ' - ' . date('d-m-Y', strtotime($leave->to))));
        }
        $leave->save();

        $text = ($leave->status == 2)?'approved':'declined';
        return redirect()->back()->with("success","Leave application $text successfully !");
    }

    public function getSub(Request $request) {
        $cat = $request->input('cat');
        $subcats = \App\ServiceCategory::where(['parent_id' => $cat, 'status' => 1])
                                            ->pluck('category', 'id');

        return response($subcats, 200)
                ->header('Content-Type', 'application/json');
    }

    public function changeItemStatus($id, Request $request) {
        $status = $request->status;

        $lineItem = \App\OrderItem::find($id);
        
        /*if($lineItem->order->user_id != Auth::user()->id)
            abort(403);*/

        $lineItem->status = $status;
        $lineItem->save();

        if(!is_null($request->_serC)) {
            $user = \App\User::find($lineItem->item_id);
            Mail::to($user)->send(new ServiceCancelled($user, $lineItem));
        }

        if(!is_null($request->_for)) {
            $admin = \App\Setting::find('3');
            $adminBalance = \App\Credit::where('user_id', $admin->value)->first();
            $adminBalance->balance -= ($lineItem->qty * $lineItem->amount);
            $adminBalance->save();

            $balance = \App\Credit::where('user_id', $lineItem->order->user_id)
                                    ->first();
            $balance->balance += ($lineItem->qty * $lineItem->amount);
            $balance->save();
        }

        return redirect()->back()->with("success", "Item status updated successfully !");
    }

    public function refund($id, Request $request) {
        $lineItem = \App\OrderItem::find($id);

        if($lineItem->status == 8) {
            $admin = \App\Setting::find('3');
            $adminBalance = \App\Credit::where('user_id', $admin->value)->first();
            $adminBalance->balance -= $lineItem->commision;
            $adminBalance->save();

            $balance = \App\Credit::where('user_id', $lineItem->order->user_id)
                                ->first();
            $balance->balance += $lineItem->commision;
            $balance->save();

            $text = 'Commission refunded to customer';

            $lineItem->status = 10;
            $lineItem->save();
        } else {
            $balance = \App\Credit::where('user_id', $lineItem->order->user_id)
                                ->where('balance', '>=', ($lineItem->amount + $lineItem->invoice->commision - $lineItem->commision))
                                ->first();
            if($balance) {
                $balance->balance -= ($lineItem->amount + $lineItem->invoice->commision - $lineItem->commision);
                $balance->save();
            }

            $admin = \App\Setting::find('3');
            $adminBalance = \App\Credit::where('user_id', $admin->value)->first();
            $adminBalance->balance += $lineItem->invoice->commision;
            $adminBalance->save();

            $workerBalance = \App\Credit::where('user_id', $lineItem->item_id)->first();
            if($workerBalance) {
                $workerBalance->save();
                $workerBalance->balance += ($lineItem->amount + $lineItem->invoice->commision - $lineItem->commision);
            }

            $text = 'Payment released to worker';

            $lineItem->status = 11;
            $lineItem->save();
        }        

        return redirect()->back()->with("success", $text);
    }

    public function attributes()
    {
        return [
            'addr'  => 'Address',
            'pin_code' => 'Pin Code',
            'did' => 'District',
            'phone'  => 'Phone',
            'sec_q'  => 'Security question',
            'sec_a'  => 'Security answer',
            'exp_proof'  => 'Experience proof',
            'id_proof'  => 'Identity proof',
            'scat' => 'Service category',
            'per_hour_amount' => 'Per hour amount',
            'from' => 'From date',
            'to' => 'To date',
            'reason' => 'Reason',
            'cardName' => 'Name on Card',
            'cardNumber' => 'Card Number',
            'expiry' => 'Expiry Date',
            'cvv' => 'CVV Code',
        ];
    }
}