<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;

class ProductCategoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'role:admin']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   
        $product_categories = \App\ProductCategory::orderBy('status', 'desc')->paginate(config('app.per_page'));
        return view('product_categories.index', ['product_categories' => $product_categories]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {    
        return view('product_categories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store(Request $request)
    {        
        $fields = array('category' => 'required|alpha_spaces');
        
        $validator = Validator::make($request->all(), $fields, [], $this->attributes());

        if ($validator->fails()) 
            return redirect('product-categories/create')
                        ->withErrors($validator)
                        ->withInput();
        
        $product_category = new \App\ProductCategory;
        $product_category->category = $request->category;

        $product_category->save();
        return redirect('product-categories/')->with("success","Product category saved successfully !");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        $product_category = \App\ProductCategory::findOrFail($id);
        
        return view('product_categories.edit', ['product_category' => $product_category]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category' => 'required|alpha_spaces',
        ], [], $this->attributes());

        if ($validator->fails()) 
            return redirect('product-categories/'.$id.'/edit')
                        ->withErrors($validator)
                        ->withInput();

        $product_category = \App\ProductCategory::find($id);
        $product_category->category = $request->category;
        
        $product_category->save();
        return redirect('product-categories')->with("success","Product category updated successfully !");
    }

    public function attributes()
    {
        return [
            'category' => 'Category Name',
        ];
    }

    public function disable($id) {
        $product_category = \App\ProductCategory::find($id);
        $product_category->status = 1 - $product_category->status;
        $product_category->save();

        //Disable products also
        if(!$product_category->status)
            \App\Product::where('product_category', $id)->delete();
        else
            \App\Product::withTrashed()
                            ->where('product_category', $id)
                            ->restore();

        $text = ($product_category->status)?'enabled':'disabled';
        return redirect()->back()->with("success","Product category $text successfully !");
    }
}
