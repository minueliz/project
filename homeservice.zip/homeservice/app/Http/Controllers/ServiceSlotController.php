<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use Validator;

class ServiceSlotController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'role:admin']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   
        $serviceSlots = \App\ServiceSlot::paginate(config('app.per_page'));
        return view('service_slots.index', ['serviceSlots' => $serviceSlots]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        $slot = \App\ServiceSlot::findOrFail($id);

        return view('service_slots.edit', ['slot' => $slot]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id, Request $request)
    {
        \App\ServiceSlot::truncate();        
        
        foreach ($request->slots as $value) {
            $slot = new \App\ServiceSlot;
            $slot->slot = $value;
            $slot->save();
        }

        return redirect('service-slots')->with("success","Service slots updated successfully !");
    }

    public function disable($id) {
        $slot = \App\ServiceSlot::find($id);
        $slot->status = 1 - $slot->status;
        $slot->save();

        $text = ($slot->status)?'enabled':'disabled';
        return redirect()->back()->with("success","Service slot $text successfully !");
    }
}
