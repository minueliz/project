<?php 

namespace App\Providers;

use App\Services\Cart\CartExtended;
use Illuminate\Support\ServiceProvider;

class CartExtendedServiceProvider extends ServiceProvider {

	/**
	 * Bootstrap the application services.
	 *
	 * @return void
	 */
	public function boot()
	{
	    //
	}

	/**
	 * Register the application services.
	 *
	 * @return void
	 */
	public function register()
	{
	    $this->app->singleton('cartExtended', function ($app) {
			$session = $app['session'];
	        $events = $app['events'];
			
			return new CartExtended($session, $events);			
		});
	}
}