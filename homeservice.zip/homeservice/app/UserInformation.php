<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserInformation extends Model
{
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'user_id', 'addr', 'district_id', 'pin_code', 'phone', 'alt_phone', 'sec_q', 'sec_a', 'img', 'exp_proof', 'id_proof', 'per_hour_amount'
    ];    

    protected $primaryKey = 'id';

    public $table = "user_informations";

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function sec_question()
    {
        return $this->hasOne('App\SecQuestion', 'id', 'sec_q');
    }

    public function district()
    {
        return $this->hasOne('App\District', 'id', 'district_id');
    }

    public function category()
    {
        return $this->hasOne('App\ServiceCategory', 'id', 'service_category');
    }
}
