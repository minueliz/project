-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2019 at 08:27 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hs`
--

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(11) NOT NULL,
  `district` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `district`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Kottayam', 1, NULL, NULL),
(2, 'Kozhikkode', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(6, '2014_10_12_000000_create_users_table', 1),
(7, '2014_10_12_100000_create_password_resets_table', 1),
(8, '2019_03_13_024148_create_permission_tables', 1),
(9, '2019_03_14_085021_user_info_table', 1),
(10, '2019_03_14_093439_sec_q_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(1, 'App\\User', 2),
(1, 'App\\User', 3),
(1, 'App\\User', 4),
(1, 'App\\User', 5),
(1, 'App\\User', 12),
(1, 'App\\User', 13),
(1, 'App\\User', 14),
(1, 'App\\User', 15),
(1, 'App\\User', 16),
(1, 'App\\User', 17),
(1, 'App\\User', 18),
(1, 'App\\User', 19),
(1, 'App\\User', 20),
(1, 'App\\User', 21),
(1, 'App\\User', 22),
(1, 'App\\User', 23),
(1, 'App\\User', 24),
(1, 'App\\User', 25),
(1, 'App\\User', 30),
(1, 'App\\User', 31),
(1, 'App\\User', 32),
(1, 'App\\User', 33),
(1, 'App\\User', 34),
(1, 'App\\User', 35),
(1, 'App\\User', 36),
(1, 'App\\User', 37),
(1, 'App\\User', 38),
(1, 'App\\User', 39),
(1, 'App\\User', 40),
(1, 'App\\User', 41),
(1, 'App\\User', 42),
(1, 'App\\User', 43),
(1, 'App\\User', 59),
(2, 'App\\User', 6),
(2, 'App\\User', 7),
(2, 'App\\User', 8),
(2, 'App\\User', 9),
(2, 'App\\User', 10),
(2, 'App\\User', 26),
(2, 'App\\User', 27),
(2, 'App\\User', 28),
(2, 'App\\User', 29),
(2, 'App\\User', 44),
(2, 'App\\User', 45),
(2, 'App\\User', 46),
(2, 'App\\User', 47),
(2, 'App\\User', 48),
(2, 'App\\User', 49),
(2, 'App\\User', 50),
(2, 'App\\User', 51),
(2, 'App\\User', 52),
(2, 'App\\User', 53),
(2, 'App\\User', 54),
(2, 'App\\User', 55),
(2, 'App\\User', 56),
(2, 'App\\User', 57),
(2, 'App\\User', 58),
(2, 'App\\User', 60),
(3, 'App\\User', 11);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('minuelizminu@gmail.com', '$2y$10$Jhi4PFD/1mLfz4Ua0qDEN.zwo/oRNGsfMeyoP6cDgUHW4d4BrpRxm', '2019-03-19 03:35:10');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `transaction_id` varchar(20) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1. Reg. fee, 2.Buy, 3. Service pay',
  `amount` double NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1. Complete, 2.Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'all', 'web', '2019-03-14 09:51:31', '2019-03-14 09:51:31');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_category` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `qty` int(11) NOT NULL,
  `amount` double NOT NULL,
  `img` varchar(191) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_category`, `name`, `description`, `qty`, `amount`, `img`, `status`, `created_at`, `updated_at`) VALUES
(7, 2, 'q q', 'sdas \r\nd\r\nasd\r\nd', 23, 23, '', 1, '2019-03-17 04:18:54', '2019-03-17 11:54:37'),
(8, 6, 'P o', 'N', 1, 2, '', 1, '2019-03-18 05:48:38', '2019-03-18 05:48:38');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` int(11) NOT NULL,
  `category` varchar(191) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `category`, `status`, `created_at`, `updated_at`) VALUES
(1, 'sa', 0, NULL, '2019-03-18 01:30:01'),
(2, 'Eletrical', 1, NULL, NULL),
(6, 'Carpenter', 1, '2019-03-18 01:56:35', '2019-03-18 01:56:35'),
(7, 'Brush', 1, '2019-03-19 10:53:52', '2019-03-19 10:53:52');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `worker_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'customer', 'web', '2019-03-14 09:51:31', '2019-03-14 09:51:31'),
(2, 'worker', 'web', '2019-03-14 09:51:31', '2019-03-14 09:51:31'),
(3, 'admin', 'web', '2019-03-14 09:51:31', '2019-03-14 09:51:31');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 2),
(1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `sec_questions`
--

CREATE TABLE `sec_questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sec_questions`
--

INSERT INTO `sec_questions` (`id`, `question`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Culpa eius nulla vero?', 1, '2019-03-14 09:51:32', '2019-03-14 09:51:32'),
(2, 'Corrupti accusantium sunt saepe nemo labore?', 1, '2019-03-14 09:51:32', '2019-03-14 09:51:32'),
(3, 'Et culpa quia sed cum nemo hic qui?', 1, '2019-03-14 09:51:32', '2019-03-14 09:51:32'),
(4, 'Est pariatur quis est ut nihil?', 1, '2019-03-14 09:51:32', '2019-03-14 09:51:32'),
(5, 'Nobis eum dolor minus cupiditate fugit est?', 1, '2019-03-14 09:51:32', '2019-03-14 09:51:32');

-- --------------------------------------------------------

--
-- Table structure for table `service_categories`
--

CREATE TABLE `service_categories` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_categories`
--

INSERT INTO `service_categories` (`id`, `category`, `img`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Plumber', '', 1, NULL, '2019-03-18 01:54:34'),
(2, 'Eletrician', '', 1, NULL, '2019-03-18 01:37:51'),
(3, 'Carpenter', '', 1, '2019-03-18 01:56:22', '2019-03-18 01:56:22'),
(4, 'Cat One', '', 1, '2019-03-18 05:47:16', '2019-03-18 05:47:16'),
(5, 'Cat two', '', 1, '2019-03-18 05:47:38', '2019-03-18 05:47:38'),
(6, 'Cat three', '', 1, '2019-03-18 05:47:48', '2019-03-18 05:47:48'),
(7, 'Cleaning', 'p1553011867.png', 1, '2019-03-19 10:41:07', '2019-03-19 10:41:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `worker_approved` tinyint(4) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `status`, `worker_approved`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Golda Witting II', 'dessie81@example.org', '2019-03-14 09:51:32', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 0, 0, '6AFXM1oYPnypHL1XTx1yNDxiY7KCIgCpSTOwYZhHJ2QEShcEHYtSlO2C3j0y', '2019-03-14 09:51:32', '2019-03-17 00:45:54'),
(2, 'Prof. Hunter Hickle MD', 'drake11@example.net', '2019-03-14 09:51:32', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 0, 0, 'HwVW0ZzgXCyQlIaxncKS3i9IPz1IHgpEII6nxJATS5qsBqgC7rg0WANE3fwr', '2019-03-14 09:51:32', '2019-03-20 01:00:22'),
(3, 'Craig O\'Reilly', 'price.cristian@mailinator.com', '2019-03-14 09:51:32', '$2y$10$zuzUHJGq4b.StqdFc5Vd7e/RRdUVV4cMre44c1Xdk/sts5nWHT4p.', 1, 0, 'VhJFuYJI5Mo1dGZP2Ia0DOluUDZhtEKkMftdBKh07joONZrVzJgJxap02McM', '2019-03-14 09:51:32', '2019-03-20 13:13:52'),
(4, 'Laverna Wintheiser PhD', 'alex.hilpert@example.com', '2019-03-14 09:51:32', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 0, 0, 'P9rO3jrdaC', '2019-03-14 09:51:32', '2019-03-16 09:48:07'),
(5, 'Jamar Pagac', 'wmedhurst@example.org', '2019-03-14 09:51:32', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 0, 'Fxp3Q5pBxY', '2019-03-14 09:51:32', '2019-03-17 12:04:08'),
(6, 'Prof. Rachael Hauck Jr', 'maryam10@example.com', '2019-03-14 09:51:32', '$2y$10$bVq/lh6NX7KCbBFPbZpdKubXo.EP7QhOrPQRdkRcpEhUxNCScOFsu', 0, 0, '8Qq1RrQWUSRk9kEMcBVFifqqlKIVRbOFKIZnLbDXXYCJtoU84VQYHlz82Tcr', '2019-03-14 09:51:32', '2019-03-17 12:04:02'),
(7, 'Roscoe Gleichner', 'zgreenholt@example.net', '2019-03-14 09:51:32', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 0, 'zCv9gbjYm9AYfZXrIkiReFWYNiJ1DfNtM0P5or9tWnlDPzKKyCLTcGbjfSGp', '2019-03-14 09:51:32', '2019-03-17 12:04:00'),
(8, 'Ayla Feeney V', 'georgiana19@example.com', '2019-03-14 09:51:32', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 0, 'FSz9N3ptuY', '2019-03-14 09:51:32', '2019-03-14 09:51:32'),
(9, 'Mr. Cyrus Langosh', 'linnea08@example.net', '2019-03-14 09:51:32', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 0, 'OzRyejNlax', '2019-03-14 09:51:32', '2019-03-14 09:51:32'),
(10, 'Krystina Balistreri', 'amelie.altenwerth@example.net', '2019-03-14 09:51:32', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 0, 'p44uQKM45O', '2019-03-14 09:51:32', '2019-03-14 09:51:32'),
(11, 'Junior Gaylord', 'doug44@example.org', '2019-03-14 09:51:32', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 0, 'o2qLIeKdjpKdeYXl8wofUs9TFMe4FeiOhZgeLxjRJe7V2vdz0yy4DcXENtBI', '2019-03-14 09:51:32', '2019-03-14 09:51:32'),
(58, 'payments', 'lesly40@example.net', NULL, '$2y$10$9nxEm1GfEIrG3BORpoAD8OHfF1jNuQTNk4ygGQ7kBFgX0PfntJx0C', 1, 0, NULL, '2019-03-15 10:40:44', '2019-03-15 10:40:44'),
(59, 'minu', 'm@f', NULL, '$2y$10$M1vp1h2Epksohr5bBlUnbelp65FWVeGeB4v2E5pmGRCpveN5RcLjG', 1, 0, NULL, '2019-03-19 03:23:33', '2019-03-19 20:23:28'),
(60, 'kevin', 'minuelizminu@gmail.com', NULL, '$2y$10$svlvfm4TuZW0.IFaFfTfyekR9bHnd9JZkrDi4QzjOODvL1mHL20ru', 0, 0, NULL, '2019-03-19 03:31:05', '2019-03-19 03:34:16');

-- --------------------------------------------------------

--
-- Table structure for table `user_informations`
--

CREATE TABLE `user_informations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `service_category` bigint(20) UNSIGNED DEFAULT NULL,
  `addr` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` int(11) DEFAULT NULL,
  `pin_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sec_q` int(11) DEFAULT NULL,
  `sec_a` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_proof` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_proof` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `per_hour_amount` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_informations`
--

INSERT INTO `user_informations` (`id`, `user_id`, `service_category`, `addr`, `district_id`, `pin_code`, `phone`, `alt_phone`, `sec_q`, `sec_a`, `img`, `exp_proof`, `id_proof`, `per_hour_amount`, `created_at`, `updated_at`) VALUES
(47, 58, 1, 'ft', 1, '121212', '6282259808', NULL, 1, 'lesly40@example.net', '', 'e1552666244.jpg', 'a1552666244.jpg', 0, '2019-03-15 10:40:44', '2019-03-15 10:40:44'),
(48, 1, NULL, 'qww', 1, '12121', '1212121', NULL, 2, '', NULL, NULL, NULL, 0, NULL, NULL),
(49, 5, NULL, '', 1, '', '', NULL, 2, '', NULL, NULL, NULL, 0, NULL, NULL),
(50, 11, 1, '', 1, '', '', NULL, 2, '', NULL, NULL, NULL, 0, NULL, NULL),
(51, 7, 1, 'sas', 1, '1222', '231331313', NULL, 1, '123', NULL, NULL, NULL, 0, NULL, '2019-03-17 03:51:18'),
(52, 59, NULL, '990', 1, '54', '9090909090', 'ijmko;j', 1, '9', '', '', '', 0, '2019-03-19 03:23:33', '2019-03-19 03:23:33'),
(53, 60, 2, 'djfcvjb', 1, '00', '9090909090', 'nlkml', 2, '0', 'p1552986065.png', 'e1552986065.png', 'a1552986065.png', 0, '2019-03-19 03:31:05', '2019-03-19 03:31:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `sec_questions`
--
ALTER TABLE `sec_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_categories`
--
ALTER TABLE `service_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_informations`
--
ALTER TABLE `user_informations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_informations_user_id_unique` (`user_id`),
  ADD KEY `user_informations_sec_q_foreign` (`sec_q`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sec_questions`
--
ALTER TABLE `sec_questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `service_categories`
--
ALTER TABLE `service_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `user_informations`
--
ALTER TABLE `user_informations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
