@component('mail::message')
Dear {{ $name }},

User <b>{{ $service->order->user->name }}</b> has cancelled the order, #<b><a href="{{ URL::to('service-requests/' . $service->id) }}">{{ $service->id }}</a></b>. 

Thanks,<br>
{{ config('app.name') }}
@endcomponent