@component('mail::message')
Dear {{ $name }},

Your account has been approve by Administrator. You may now login by clicking on the below link.

@component('mail::button', ['url' => url('/')])
Login
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent