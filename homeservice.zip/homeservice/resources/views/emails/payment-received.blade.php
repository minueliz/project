@component('mail::message')
Dear {{ $name }},

User <b>{{ $service->order->user->name }}</b> has paid for the order, #<b><a href="{{ URL::to('service-requests/' . $service->id) }}">{{ $service->id }}</a></b>. 
Find below the details,<br>
Date: {{ date('d-m-Y') }}<br>
Service Date: {{ date('d-m-Y', strtotime($service->service_slot_from)) }}<br>
Service Slot: {{ date('H:i', strtotime($service->service_slot_from)) }} - 
                            {{ date('H:i', strtotime($service->service_slot_to)) }}<br>
Admin commission: {!! config('app.currency') !!}{{ number_format($service->commision, 2) }}<br>

Thanks,<br>
{{ config('app.name') }}
@endcomponent