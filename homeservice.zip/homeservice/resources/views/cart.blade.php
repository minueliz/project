@extends('layouts.app')
@section('title', '| Edit Profile')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <h1>Items in Your Cart</h1>
            <div class="cart-list col-md-12">
            	
            	<table class="table table-responsive">
            	@foreach($cartCon as $key => $con)
            	  <tr>
            	  	<td class="prod-list-img">
            	  		@if(get_class($con->model) == 'App\Product')
							@if(!empty($con->model->img))
				                <img class="img-responsive" src="{{URL::asset('images/products')}}/{{$con->model->img}}" >
				            @else
				                <img class="img-responsive" src="{{URL::asset('images/products')}}/214x150.png" >
				            @endif
				        @else
				        	<img class="img-responsive" src="{{URL::asset('images/profile')}}/{{$con->model->userinformation->img}}" >
				        @endif
			        </td>
			        <td>
					    <h5 class="prod-title">{!! $con->name !!}</h5>
						@if(get_class($con->model) == 'App\Product')
							@php
								$hasProd = true;
							@endphp
						    <h6 class="prod-desc">
						    	{{ ucfirst((strlen($con->model->description) > 170)?substr($con->model->description, 0, 170).'...':$con->model->description) }}
						    </h6>
						@else
							@php
								$hasServ = true;
							@endphp
						@endif
						<span class="invalid-feedback mt-2 d-block" role="alert">
                            <strong>{{ $errors->first('msg'.$key) }}</strong>
                      </span>
					</td>
					@if(get_class($con->model) == 'App\Product')
						<td width="100px">						
						  	{{ Form::open(array('url' => 'cart/update-quantity', 'class' => 'pull-right')) }}
		                      {{ Form::hidden('_method', 'PUT') }}
		                      {{ Form::hidden('rowId', $con->rowId) }}
		                      {{ Form::text('qty'.$con->id, $con->qty, array('class' => $errors->has('qty'.$con->id) ? 'form-control numeric qty is-invalid' : 'form-control numeric qty', 'minlength' => 1, 'maxlength' => '3', (get_class($con->model) == 'App\User')?'readonly':'')) }}
		                      <span class="invalid-feedback mt-2 customErr" role="alert">
		                            <strong>{{ $errors->first('qty'.$con->id) }}</strong>
		                      </span>
		                      {{ Form::submit('Update', array('class' => 'btn btn-sm btn-secondary mt-1')) }}
		                    {{ Form::close() }}
						</td>						
					@else
						<td class="prod-list-img">
							{!! nl2br($con->options->description) !!}<br>
							@if(!is_null($con->options->img))
								<img class="img-responsive" src="{{URL::asset('images/serv')}}/{{$con->options->img}}" >
							@endif
						</td>
					@endif
					<td width="150px">						
						<div class="prod-amount">{!! config('app.currency') !!}{{ number_format(($con->price*$con->qty), 2) }}</div>
					</td>
					<td>
					  {{ Form::open(array('url' => 'cart/remove', 'class' => 'pull-right')) }}
	                      {{ Form::hidden('_method', 'PUT') }}
	                      {{ Form::hidden('rowId', $con->rowId) }}
	                      {{ Form::submit('Remove', array('class' => 'btn btn-sm btn-danger')) }}
	                  {{ Form::close() }}
					</td>
				  </tr>

            	@endforeach
            	@if(count($cartCon))
	            	<tr>
	            		<td colspan="3" class="text-right">Total: </td>
	            		<td>
	            			<span class="totalCart">{!! config('app.currency') !!}{{ number_format($total, 2) }}</span>
	            		</td>
	            		<td></td>
	            	</tr>
	            @if(isset($hasServ) && $hasServ)
	            	<tr>
	            		<td colspan="2" class="text-right">*You will pay for service after the worker approves the slot. </td>
	            		<td colspan="1" class="text-right">Total payable: </td>
	            		<td colspan="2">
	            			<span class="totalCart">{!! config('app.currency') !!}{{ number_format($payable, 2) }}</span>
	            		</td>
	            	</tr>
	            @endif
	            	<tr>
	            		<td colspan="5" class="text-right">
	            			{{ Form::open(array('url' => 'cart/checkout', 'class' => 'float-right')) }}
    							{{ Form::hidden('_method', 'PUT') }}
	            				{{ Form::submit((!$hasProd)?'Book':'Pay', array('class' => 'btn btn-sm btn-primary show-pay')) }}
	            			{{ Form::close() }}
	            		</td>
	            	</tr>
	            @else
	            	<tr>
	            		<td colspan="5">
	            			Your Cart is Empty!
	            		</td>
	            	</tr>
	            @endif
            	</table>
          	</div>
        </div>
        {{ Form::open(array('url' => 'cart/checkout', 'class' => 'float-right w-100 dis-none paymentForm')) }}
        	{{ Form::hidden('_method', 'PUT') }}
        	<!-- if there are creation errors, they will show here -->
			@if ($errors->any())
				<div class="alert alert-danger hideIf">
					<ul>
						@foreach ($errors->all() as $error)
			                <li>{!! $error !!}</li>
			            @endforeach
					</ul>
				</div>
			@endif
			<div class="col-xs-12 col-md-12 mb-5">
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                    <h1 class="panel-title">
	                        Address
	                    </h1>
	                </div>
	                @if(isset($hasProd) && $hasProd)
	                <div class="row">
		                <div class="panel-body col-md-4">
		                    <div class="form-group">
		                        <label for="cardName">
		                            Shipping Address</label>
		                        <div class="input-group">
		                            {{ Form::textarea('shipping_addr', $addr, array('class' => 'form-control', 'rows' => '3', 'autofocus')) }}
		                        </div>
		                    </div>
		            	</div>
		            </div>
		           	@endif
		           	@if(isset($hasServ) && $hasServ)
		           	<div class="row">
		           		<div class="panel-body col-md-4">
		                    <div class="form-group">
		                        <label for="cardName">
		                            Service Address</label>
		                        <div class="input-group">
		                            {{ Form::textarea('service_addr', $addr, array('class' => 'form-control', 'rows' => '3', 'autofocus')) }}
		                        </div>
		                    </div>
		            	</div>
		            </div>
		           	@endif
	            </div>
	        </div>
	        <div class="col-xs-12 col-md-4 mb-5">
	        	@if(isset($hasProd) && $hasProd)
	            <div class="panel panel-default">
	                <div class="panel-heading">
	                    <h1 class="panel-title">
	                        Payment Details
	                    </h1>
	                </div>
	                <div class="panel-body">
	                    <div class="form-group">
	                        <label for="cardName">
	                            Name on Card</label>
	                        <div class="input-group">
	                            {{ Form::text('cardName', Request::old('cardName'), array('class' => 'form-control', 'placeholder' => "", 'required')) }}
	                        </div>
	                    </div>

	                    <div class="form-group">
	                        <label for="cardNumber">
	                            Card Number</label>
	                        <div class="input-group">
	                            {{ Form::text('cardNumber', Request::old('cardNumber'), array('class' => 'form-control numeric', 'placeholder' => "4800 1234 5678 9876", 'required', 'minlength' => 14, 'maxlength' => 16)) }}
	                            <span class="input-group-addon"><span class="fa fa-lock"></span></span>
	                        </div>
	                    </div>
	                    <div class="row">
	                        <div class="col-xs-12 col-md-12">
	                            <div class="form-group">
	                                <label for="expiry">
	                                    Card Type</label>
	                                <div class="col-xs-6 col-lg-6 pl-ziro">
	                                    {!! Form::select('cardType', $cardTypes, Request::old('cardType'), ['class' => 'form-control']) !!}
	                                </div>
	                            </div>
	                        </div>
	                        <div class="col-xs-7 col-md-7">
	                            <div class="form-group">
	                                <label for="expiry">
	                                    Expiry Date</label>
	                                <div class="col-xs-6 col-lg-6 pl-ziro">
	                                    {{ Form::text('expiry', Request::old('expiry'), array('class' => 'form-control', 'placeholder' => "MM/YY", 'required', 'maxlength' => 5 )) }}
	                                </div>
	                            </div>
	                        </div>
	                        <div class="col-xs-5 col-md-5 pull-right">
	                            <div class="form-group">
	                                <label for="cvCode">
	                                    CVV</label>
	                                <div class="col-xs-7 col-lg-7 pl-ziro">
	                                	{{ Form::text('cvv', Request::old('cvv'), array('class' => 'form-control numeric', 'placeholder' => "CVV", 'minlength' => 3, 'maxlength' => 3, 'required', 'min' => 1 )) }}
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                    
	                </div>
	            </div>
	            @endif
	            {{ Form::hidden('_onlyS', (!$hasProd?1:0)) }}
	            {{ Form::submit((!$hasProd)?'Book':'Pay & Check Out', array('class' => 'btn btn-success btn-lg btn-block')) }}
	        </div>
        {{ Form::close() }}
    </div>
</div> 
@endsection
@section('scripts')
<script type="text/javascript">
$(function(){
	$("input[type='text']").on("input", function() {
	 	$(this).next().next().show();
	});

	$('.qty').keypress(function(e){
		if($(this).next().is(':visible'))
			$(this).next().hide();
	})

	$('.numeric').keypress(function(e){
		if(! /^\d*$/.test(e.key)) {
			return false;
		}
	})

	$('input[name="expiry"]').keypress(function(e){
		if(! /^\d*$/.test(e.key)) {
			return false;
		}

		if($(this).val().length >= 2 && e.keyCode !== 46 && e.keyCode !== 8) {
			if($(this).val().indexOf('/') === -1)
				$(this).val($(this).val().substr(0, 2) + '/' + $(this).val().substr(2))
		}

		if($(this).val().length >= 5)
			$(this).val($(this).val().substr(0, 5))	
	})

	$('input[name="expiry"]').on('paste', function(e){
		return false;
	})
	@guest
	@else
		@if ($errors->any())
			if(!$('.customErr').is(':visible')) {
				$('.show-pay').hide();
				$('.paymentForm').show();	
			}
		@endif

		$('.show-pay').click(function(e){
			$(this).hide();
			$('.paymentForm').show();

			$('.customErr').hide();
			$('.hideIf').hide();

			$('.qty').each(function(){
				$(this).removeClass('is-invalid')
			})
			e.preventDefault();
		})
	@endguest	
	$(document).on('submit', 'form', function() {
	    $(this).find('button:submit, input:submit').attr('disabled', 'disabled');
	});
});
</script>
@endsection