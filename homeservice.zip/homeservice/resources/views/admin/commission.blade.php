@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Revenue from services</div>

                <div class="card-body">
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif 
                    {{ Form::open(['url' => '/commission', 'method' => 'get', 'style' => 'width:100%', 'class' => 'mt-3 ml-3']) }}
                      <fieldset class="search">
                          <div class="form-group row" style="line-height:35px">
                            <div class="col-md-3">
                              Year {!! Form::select('year', [0 => 'All', 2019 => '2019'], $year, ['class' => 'form-control m-bot15 float-right', 'id' => 'cat', 'style' => 'width:auto']) !!}
                            </div>
                            <div class="col-md-3 mr-2">
                              Month {!! Form::select('month', [0 => 'All', 1 => 'January', 
                                                                          2 => 'February', 
                                                                          3 => 'March',
                                                                          4 => 'April',
                                                                          5 => 'May',
                                                                          6 => 'June',
                                                                          7 => 'July',
                                                                          8 => 'August',
                                                                          9 => 'September',
                                                                          10 => 'October',
                                                                          11 => 'November',
                                                                          12 => 'December'
                                ], $month, ['class' => 'form-control m-bot15 float-right', 'id' => 'cat', 'style' => 'width:auto']) !!}                              
                            </div>
                          {{ Form::submit('Search', array('class' => 'btn btn-primary')) }}
                        </div>
                      </fieldset>
                    {{ Form::close() }}
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Order #</th>
                          <th scope="col">Date</th>
                          <th scope="col">Amount</th>
                          <th scope="col">Commission</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          @foreach($orders as $order)
                          <tr>
                              <td>
                                <a href="{{ URL::to('order-details/' . $order->id) }}">#{{ str_pad($order->id, 4, '0', STR_PAD_LEFT) }}</a>
                              </td>
                              <td>
                                {{ date('d-m-Y', strtotime($order->created_at)) }}
                              </td>
                              <td>{{ $order->amount }}</td>
                              <td>{{ number_format($order->commision, 2) }}</td>
                            </tr>
                          @endforeach
                          @if(!count($orders))
                            <tr class="no-rec">
                              <td colspan="4">No records!</td>
                            </tr>
                          @endif
                          <tr>
                            <td colspan="3">Total</td>
                            <td>{!! config('app.currency') !!}{{ number_format($total, 2) }}</td>
                          </tr>
                        </tbody>
                    </table>
                  {!! $orders->appends(\Request::except('page'))->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
