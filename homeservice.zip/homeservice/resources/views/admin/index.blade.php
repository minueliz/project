@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                          {{ Html::ul($errors->all()) }}
                        </div>
                    @endif
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif 
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs">
                      <li class="nav-item">
                        <a class="nav-link" href="#settings" data-toggle="tab" role="tab" aria-controls="settings" aria-selected="true">Settings</a>
                      </li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                     <div role="tabpanel" class="tab-pane fade show active" id="settings">
                        <p class="mt-2">
                            {{ Form::open(array('url' => 'admin/save-settings', 'class' => 'pull-right')) }}
                                {{ Form::hidden('_method', 'PUT') }}
                                @foreach($settings as $setting) @php if($setting->id == 3) continue; @endphp
                                    <div class="form-group row">
                                    @if($setting->id == 1)
                                      {{ Form::label($setting->key, 'Worker leave per year', array('class' => 'col-md-4 control-label text-md-right')) }}
                                    @else
                                        {{ Form::label($setting->key, 'Admin commision', array('class' => 'col-md-4 control-label text-md-right')) }}
                                    @endif
                                      <div class="col-md-4">
                                        {{ Form::text($setting->key, $setting->value, array('class' => 'form-control', 'maxLength' => 2)) }}
                                      </div>
                                    </div>
                                @endforeach
                                <div class="form-group row">
                                    <div class="col-md-4 offset-md-4">
                                        {{ Form::submit('Update', array('class' => 'btn btn-sm btn-primary')) }}
                                    </div>
                                </div>         
                            {{ Form::close() }}
                        </p>
                     </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
<script type="text/javascript">
$(function(){
    $('input').keypress(function(e){
        if(! /^\d*$/.test(e.key)) {
            return false;
        }
    });
});
</script>
@endsection