<nav class="navbar navbar-expand-md navbar-light navbar-laravel main-menu">
    <div class="container">
        <a class="navbar-brand" href="{{ url('/') }}">
            {{ config('app.name', 'Laravel') }}
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <li class="nav-item">
                    @role('admin')
                        <a class="nav-link" href="{{ url('/admin') }}">Home</a>
                    @else
                        <a class="nav-link" href="{{ url('/') }}">Home</a>
                    @endif
                </li>
                @role('admin')
                @else
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/shop') }}">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/services') }}">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/about-us') }}">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/contact') }}">Contact</a>
                    </li>
                @endif
                @if(Cart::count())
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('cart') }}">
                            <i class="fas fa-shopping-cart">
                                <span class="count" value="{{ $qty }}"></span>
                            </i>
                        </a>
                    </li>
                @endif
                @guest
                    <li class="nav-item">
                        <a class="nav-link spec-link-login" href="{{ route('login') }}">{{ __('Login') }}</a>
                    </li>
                    @if (Route::has('register'))
                        <li class="nav-item">
                            <a class="nav-link spec-link-reg" href="{{ route('register') }}">{{ __('Register') }}</a>
                        </li>
                    @endif
                @else
                    @if(!empty($img))
                    <li>
                        <div class="inset">
                          <img src="{{URL::asset('images/profile')}}/{{$img}}">
                        </div>
                    </li>
                    @endif
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ ucfirst(Auth::user()->name) }} <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            @role('admin')
                            @else
                                @role('worker')
                                    <a class="dropdown-item" href="{{ url('leaves') }}">
                                        {{ __('Apply for leave') }}
                                    </a>
                                    <a class="dropdown-item" href="{{ url('service-requests') }}">
                                        {{ __('Service requests') }}
                                    </a>
                                @endif
                                <a class="dropdown-item" href="{{ url('orders') }}">
                                    {{ __('My orders') }}
                                </a>
                                <a class="dropdown-item" href="{{ url('my-profile') }}">
                                    {{ __('My profile') }}
                                </a>
                                <a class="dropdown-item" href="{{ url('edit-profile') }}">
                                    {{ __('Edit profile') }}
                                </a>
                            @endif
                            <a class="dropdown-item" href="{{ route('change-password') }}">
                                {{ __('Change password') }}
                            </a>
                            
                            <a class="dropdown-item" href="{{ route('logout') }}"
                               onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>
                        </div>
                    </li>
                @endguest
            </ul>
        </div>
    </div>
</nav>