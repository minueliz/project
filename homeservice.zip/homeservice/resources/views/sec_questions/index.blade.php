@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Security Questions</div>

                <div class="card-body">
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          @foreach($sec_questions as $sec_question)
                          <tr>
                              <td>
                                {{ $sec_question->question }}
                              </td>
                              <td>
                                <a class="btn btn-sm btn-info edit-btn" href="{{ URL::to('security-questions/' . $sec_question->id . '/edit') }}">Edit</a>
                                {{ Form::open(array('url' => 'security-questions/disable/' . $sec_question->id, 'class' => 'pull-right')) }}
                                    {{ Form::hidden('_method', 'POST') }}
                                    
                                        {{ Form::submit(($sec_question->status)?'Disable':'Enable', array('class' => ($sec_question->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary')) }}

                                  {{ Form::close() }}                                
                              </td>
                            </tr>
                          @endforeach
                          @if(!count($sec_questions))
                            <tr class="no-rec">
                              <td colspan="2">No records!</td>
                            </tr>
                          @endif
                        </tbody>
                    </table>
                  {!! $sec_questions->appends(\Request::except('page'))->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
