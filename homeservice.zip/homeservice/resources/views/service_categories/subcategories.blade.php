@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Service Subcategories</div>

                <div class="card-body">
                  @if (session('error'))
                      <div class="alert alert-danger">
                          {{ session('error') }}
                      </div>
                  @endif
                  @if (session('success'))
                      <div class="alert alert-success">
                          {{ session('success') }}
                      </div>
                  @endif 
                    {{ Form::open(['url' => '/service-categories/subcategories/list', 'method' => 'get', 'style' => 'width:100%']) }}
                      <fieldset class="search">
                          <div class="form-group row">
                          <div class="col-md-3">
                            {!! Form::select('pcategory', $serviceCats, $pcategory, ['class' => 'form-control m-bot15', 'id' => 'pcategory']) !!} 
                          </div>
                        </div>
                      </fieldset>
                      {{ Form::close() }}
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col"></th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          @foreach($subCats as $service_category)
                          <tr>
                              <td>
                                {{ $service_category->category }}
                              </td>
                              <td>
                                @if(!empty($service_category->img))
                                  <div class="form-group row offset-md-4">
                                    <div class="col-md-4">
                                      <img class="productpic" src="{{URL::asset('images/service-categories')}}/{{$service_category->img}}">
                                    </div>
                                  </div>
                                @endif
                              </td>
                              <td>
                                <a class="btn btn-sm btn-info edit-btn" href="{{ URL::to('service-categories/' . $service_category->id . '/edit/sub') }}">Edit</a>
                                {{ Form::open(array('url' => 'service-categories/disable/' . $service_category->id, 'class' => 'pull-right')) }}
                                    {{ Form::hidden('_method', 'POST') }}
                                    
                                        {{ Form::submit(($service_category->status)?'Disable':'Enable', array('class' => ($service_category->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary')) }}

                                  {{ Form::close() }}                                
                              </td>
                            </tr>
                          @endforeach
                          @if(!count($subCats))
                            <tr class="no-rec">
                              <td colspan="3">No records!</td>
                            </tr>
                          @endif
                        </tbody>
                    </table>
                  {!! $subCats->appends(\Request::except('page'))->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
<script type="text/javascript">
  $( document ).ready(function() {
    $('#pcategory').change(function(){
      this.form.submit(); 
    }) 
  })
</script>
@endsection