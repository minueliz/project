@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Service Categories</div>

                <div class="card-body">
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col"></th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          @foreach($service_categories as $service_category)
                          <tr>
                              <td>
                                {{ $service_category->category }}
                              </td>
                              <td>
                                @if(!empty($service_category->img))
                                  <div class="form-group row offset-md-4">
                                    <div class="col-md-4">
                                      <img class="productpic" src="{{URL::asset('images/service-categories')}}/{{$service_category->img}}">
                                    </div>
                                  </div>
                                @endif
                              </td>
                              <td>
                                <a class="btn btn-sm btn-info edit-btn" href="{{ URL::to('service-categories/' . $service_category->id . '/edit') }}">Edit</a>
                                {{ Form::open(array('url' => 'service-categories/disable/' . $service_category->id, 'class' => 'pull-right')) }}
                                    {{ Form::hidden('_method', 'POST') }}
                                    
                                        {{ Form::submit(($service_category->status)?'Disable':'Enable', array('class' => ($service_category->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary')) }}

                                  {{ Form::close() }}                                
                              </td>
                            </tr>
                          @endforeach
                          @if(!count($service_categories))
                            <tr class="no-rec">
                              <td colspan="3">No records!</td>
                            </tr>
                          @endif
                        </tbody>
                    </table>
                  {!! $service_categories->appends(\Request::except('page'))->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
