@extends('layouts.app')
@section('title', '| Create New Event')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                  Product Details                  
                </div>

                <div class="card-body">

                  <div class="form-group row">
                      {{ Form::label('name', 'Name', array('class' => 'col-md-4 control-label text-md-right')) }}
                      <div class="col-md-4">
                        {{ $product->name }}
                      </div>
                  </div>
                  <div class="form-group row">
                      {{ Form::label('description', 'Description', array('class' => 'col-md-4 control-label text-md-right')) }}
                      <div class="col-md-4">
                        {!! nl2br($product->description) !!}
                      </div>
                  </div>

                  <div class="form-group row">
                      {{ Form::label('cat', 'Category', array('class' => 'col-md-4 control-label text-md-right')) }}
                      <div class="col-md-4">
                        {{ $product->category->category }}
                      </div>
                  </div>

                  <div class="form-group row">
                      {{ Form::label('qty', 'Quantity', array('class' => 'col-md-4 control-label text-md-right')) }}
                      <div class="col-md-4">
                        {{ $product->qty }}
                      </div>
                  </div>

                  <div class="form-group row">
                      {{ Form::label('amount', 'Amount', array('class' => 'col-md-4 control-label text-md-right')) }}
                      <div class="col-md-4">
                        {{ number_format($product->amount, 2) }}
                      </div>
                  </div>

                  @if(!empty($product->img))
                    <div class="form-group row offset-md-4">
                      <div class="col-md-4">
                        <img class="profilepic" src="{{URL::asset('images/products')}}/{{$product->img}}">
                      </div>
                    </div>
                  @endif         

                </div>
            </div>
        </div>
    </div>
</div> 
@endsection