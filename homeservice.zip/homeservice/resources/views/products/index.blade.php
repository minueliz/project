@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col">Cateogry</th>
                          <th scope="col">Quantity</th>
                          <th scope="col">Amount</th>
                          <th scope="col" width="100px"></th>
                          <th scope="col" width="144px">Action</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          @foreach($products as $product)
                          <tr>
                              <td>
                                <a href="{{ URL::to('products/' . $product->id) }}">{{ $product->name }}</a>
                              </td>
                              <td>{{ $product->category->category }}</td>
                              <td>{{ $product->qty }}</td>
                              <td>{{ number_format($product->amount, 2) }}</td>
                              <td>
                                @if(!empty($product->img))
                                  <img class="productpic" src="{{URL::asset('images/products')}}/{{$product->img}}">
                                @endif
                              </td>
                              <td>
                                <a class="btn btn-sm btn-info approve-btn" href="{{ URL::to('products/' . $product->id . '/edit') }}">Edit</a>
                                {{ Form::open(array('url' => 'products/disable/' . $product->id, 'class' => 'pull-right')) }}
                                    {{ Form::hidden('_method', 'POST') }}
                                    
                                        {{ Form::submit(($product->status)?'Disable':'Enable', array('class' => ($product->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary')) }}

                                  {{ Form::close() }}                                
                              </td>
                            </tr>
                          @endforeach
                          @if(!count($products))
                            <tr class="no-rec">
                              <td colspan="5">No records!</td>
                            </tr>
                          @endif
                        </tbody>
                    </table>
                  {!! $products->appends(\Request::except('page'))->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
