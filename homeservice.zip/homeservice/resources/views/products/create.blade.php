@extends('layouts.app')
@section('title', '| Add New Product')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            @include('layouts.sidebar')
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Add product</div>

                <div class="card-body">
                  <!-- if there are creation errors, they will show here -->
                  @if ($errors->any())
                    <div class="alert alert-danger">
                      {{ Html::ul($errors->all()) }}
                    </div>
                  @endif

                  {{ Form::open(array('url' => 'products', 'enctype' => 'multipart/form-data')) }}
                    <div class="lds-dual-ring"></div>
                    <fieldset>
                      <div class="form-group row">
                          {{ Form::label('name', 'Name', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('name', Request::old('name'), array('class' => 'form-control')) }}
                          </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('description', 'Description', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::textarea('description', null, array('class' => 'form-control', 'rows' => '3')) }}
                          </div>
                      </div>

                      <div class="form-group row insertAfter">
                          {{ Form::label('cat', 'Category', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {!! Form::select('cat', $categories, null, ['class' => 'form-control m-bot15']) !!}
                          </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('qty', 'Quantity', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('qty', Request::old('qty'), array('class' => 'form-control')) }}
                          </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('amount', 'Amount', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('amount', Request::old('amount'), array('class' => 'form-control', 'placeholder' => "0.00")) }}
                          </div>
                      </div>

                      <div class="form-group row">
                            {{ Form::label('image', 'Image', array('class' => 'col-md-4 control-label text-md-right')) }}
                            <div class="col-md-4">
                              {{ Form::file('image', array('class' => $errors->has('image') ? 'form-control is-invalid' : 'form-control')) }}
                            </div>
                      </div>
                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          {{ Form::submit('Save', array('class' => 'btn btn-primary')) }}
                        </div>
                      </div>
                    </fieldset>
                  {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>
</div> 
@endsection