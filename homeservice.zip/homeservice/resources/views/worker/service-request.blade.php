@extends('layouts.app')
@section('title', '| User Profile')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <div class="card">                
                <div class="card-body">
                  @if (session('success'))
                      <div class="alert alert-success">
                          {{ session('success') }}
                      </div>
                  @endif 
                  <h4>Service request details</h4>
                    <div class="form-group row">
                        {{ Form::label('name', 'Customer', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ $serviceRequest->order->user->name }}
                        </div>
                    </div>

                    <div class="form-group row">
                        {{ Form::label('addr', 'Order Date', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ date('d-m-Y', strtotime($serviceRequest->created_at)) }}<br>
                        </div>
                    </div>

                    <div class="form-group row">
                        {{ Form::label('addr', 'Date', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ date('d-m-Y', strtotime($serviceRequest->service_slot_from)) }}<br>
                        </div>
                    </div>

                    <div class="form-group row">
                        {{ Form::label('addr', 'Address', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {!! nl2br($serviceRequest->order->service_addr) !!}<br>
                        </div>
                    </div>

                    <div class="form-group row">
                        {{ Form::label('addr', 'Phone', array('class' => 'col-md-4 control-label text-md-right')) }}
                        <div class="col-md-4">
                          {{ $serviceRequest->order->user->userinformation->phone }}<br>
                          @if(!empty($serviceRequest->order->user->userinformation->phone))
                            {{ $serviceRequest->order->user->userinformation->alt_phone }}
                          @endif
                        </div>
                    </div>

                    <div class="form-group row">
                          {{ Form::label('did', 'Category', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ $serviceRequest->worker->userinformation->category->category }}
                          </div>
                    </div>

                    <div class="form-group row">
                          {{ Form::label('did', 'Subcategory', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ $serviceRequest->serviceSubCat->category }}
                          </div>
                    </div>

                    <div class="form-group row">
                          {{ Form::label('did', 'Subcategory', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ $serviceRequest->serviceSubCat->category }}
                          </div>
                    </div>

                    <div class="form-group row">
                          {{ Form::label('did', 'Slot', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ date('H:i', strtotime($serviceRequest->service_slot_from)) }} - 
                            {{ date('H:i', strtotime($serviceRequest->service_slot_to)) }}
                          </div>
                    </div>

                    <div class="form-group row">
                          {{ Form::label('did', 'Description', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ $serviceRequest->description }} 
                          </div>
                    </div>

                    <div class="form-group row">
                          {{ Form::label('did', 'Image', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            <a href="{{URL::asset('images/serv')}}/{{$serviceRequest->img}}" target="_blank"><img class="w-100" src="{{URL::asset('images/serv')}}/{{$serviceRequest->img}}"></a>
                          </div>
                    </div>

                    <div class="form-group row">
                          {{ Form::label('did', 'Commission', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {!! config('app.currency') !!}{{ number_format($serviceRequest->commision, 2) }}
                          </div>
                    </div>

                    <div class="form-group row">
                          {{ Form::label('did', 'Total', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {!! config('app.currency') !!}{{ number_format($serviceRequest->amount, 2) }}
                          </div>
                    </div>
                    @if(!is_null($serviceRequest->invoice))
                      <h4>Invoice details</h4>
                      <div class="form-group row">
                          {{ Form::label('did', 'Total', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {!! config('app.currency') !!}{{ number_format($serviceRequest->amount, 2) }}
                          </div>
                      </div>
                    @endif
                </div>
            </div>
          @if($serviceRequest->status == 0)
            <div class="card mt-5">    
              <div class="card-body">                                
                  @if ($errors->has('error'))
                      <div class="alert alert-danger" id="error" tabindex='1'>
                          {{ $errors->first('error') }}
                      </div>
                  @endif
                  <h4>Update and confirm schedule</h4>
                  {{ Form::open(array('url' => '/update-schedule/'.$serviceRequest->id, 'method' => 'put', 'class' => "reviewForm")) }}
                    <div class="row">
                      <div class="col-md-2">
                        <div class="form-group">
                          <span class="form-label">Date</span>
                          {{ Form::text('bDate', $bDate, array('class' => 'form-control required', 'id' => 'bDate', 'placeholder' => 'mm/dd/yyyy')) }}
                        </div>
                      </div>
                      <div style="width:85px" class="pr-3">
                        <div class="form-group">
                          <span class="form-label">From</span>
                          {!! Form::select('slotFrom', $hours, $_slotFrom, ['class' => 'form-control required']) !!}
                          <span class="select-arrow"></span>
                        </div>
                      </div>
                      <div style="width:85px">
                        <div class="form-group">
                          <span class="form-label">To</span>
                          {!! Form::select('slotTo', $hours, $_slotTo, ['class' => 'form-control required']) !!}
                          <span class="select-arrow"></span>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-btn">
                          <button class="submit-btn btn btn-primary mt-4">Confirm</button>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-btn">
                          <button class="submit-btn btn btn-danger mt-4" name="cancel" value="1">Cancel</button>
                        </div>
                      </div>
                    </div>
                  {{ Form::close() }}                
              </div>
            </div>
          @endif
        </div>        
    </div>
</div> 
@endsection
@section('scripts')
<script src="{{ asset('js/jquery-ui.min.js') }}" defer></script>
<script type="text/javascript">
$(function(){    
  if($( ".alert" ).length)
    $( ".alert" ).focus();

  $( "#bDate" ).datepicker({ 
                  dateFormat: 'dd-mm-yy',
                  minDate: '{{ $bDate }}'
               });

  $('select[name="slotFrom"] option[value="{{config('app.endH')}}"]').remove()
  $('select[name="slotFrom"]').click(function(){
    $('select[name="slotTo"] option').removeAttr('disabled')
    for (var i = {{config('app.startH')}}; i <= $('select[name="slotFrom"]').val(); i++) {
      $('select[name="slotTo"] option[value="'+(i < 10 ? pad("0" + i, 2) : i)+'"]').attr('disabled', 'disabled')
    };
    $('select[name="slotTo"]').val(parseInt($('select[name="slotFrom"]').val()) < 9 ? pad("0" + (parseInt($('select[name="slotFrom"]').val()) + 1), 2) : parseInt($('select[name="slotFrom"]').val()) + 1).change()
  })

  function pad (str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
  }
});
</script>
@endsection