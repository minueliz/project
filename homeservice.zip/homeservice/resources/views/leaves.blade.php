@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        @hasrole('admin')
          <div class="col-md-3">
              @include('layouts.sidebar')
          </div>
        <div class="col-md-9">
        @else
        <div class="col-md-12">
        @endhasrole
            <div class="card">
              @hasrole('worker')
                <div class="card-header">
                  Apply for leave
                </div>

                <div class="card-body">
                  @if ($errors->any())
                    <div class="alert alert-danger">
                      {{ Html::ul($errors->all()) }}
                    </div>
                  @endif
                  @if (session('success'))
                      <div class="alert alert-success">
                          {{ session('success') }}
                      </div>
                  @endif 

                  {{ Form::model(null, array('url' => array('apply-for-leave'), 'method' => 'PUT')) }}
                    <fieldset>

                      <div class="form-group row">
                          {{ Form::label('from', 'From Date', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('from', Request::old('from'), array('class' => 'form-control')) }}
                          </div>
                      </div>

                      <div class="form-group row">
                          {{ Form::label('to', 'To Date', array('class' => 'col-md-4 control-label text-md-right')) }}
                          <div class="col-md-4">
                            {{ Form::text('to', Request::old('to'), array('class' => 'form-control')) }}
                          </div>
                      </div>

                      <div class="form-group row">
                            {{ Form::label('reason', 'Reason', array('class' => 'col-md-4 control-label text-md-right')) }}
                            <div class="col-md-4">
                              {{ Form::textarea('reason', Request::old('reason'), array('class' => 'form-control', 'rows' => '3')) }}
                            </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          {{ Form::submit('Apply', array('class' => 'btn btn-primary')) }}
                        </div>
                      </div>
                    </fieldset>
                  {{ Form::close() }}

                  <h4>History</h4>
                @else
                  <div class="card-header">
                    Leave applications
                  </div>
                @endhasrole
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          @hasrole('admin')
                            <th>Name<th>
                          @endhasrole
                          <th scope="col">From</th>
                          <th scope="col">To</th>
                          <th scope="col">Reason</th>
                          <th scope="col">Status</th>
                          <th scope="col"></th>
                        </tr>
                      </thead>
                      <tbody>                        
                          @foreach($leaves as $leave)
                          <tr>
                            @hasrole('admin')
                              <td>
                                <a href="{{ URL::to('profile/' . $leave->user->id) }}">{{ $leave->user->name }}</a>
                              <td>
                            @endhasrole
                            <td>
                              {{ date('d-m-Y', strtotime($leave->from)) }}
                            </td>
                            <td>
                              {{ date('d-m-Y', strtotime($leave->to)) }}
                            </td>
                            <td>{!! nl2br($leave->reason) !!}</td>
                            <td><span class="{{ ($leave->status == 1)?'btn alert-secondary':(($leave->status == 2)?'btn alert-primary':'btn alert-danger') }}">{{ $status[$leave->status] }}</span></td>
                            @hasrole('admin')
                              <td>
                                @if($leave->status == 1)
                                  {{ Form::open(array('url' => 'leave/toggle/' . $leave->id, 'class' => 'pull-right')) }}
                                    {{ Form::hidden('_method', 'POST') }}
                                      {{ Form::submit('Approve', array('class' => 'btn btn-sm btn-primary', 'name' => 'action')) }}
                                      {{ Form::submit('Decline', array('class' => 'btn btn-sm btn-dark', 'name' => 'action')) }}
                                  {{ Form::close() }}
                                @endif
                              </td>
                            @else
                            <td>
                              @if(\App\Http\Controllers\UserController::canCancelLeave($leave))
                                {{ Form::open(array('url' => 'cancel-leave/'.$leave->id)) }}
                                    {{ Form::hidden('_method', 'PUT') }}
                                    {{ Form::hidden('status', '6') }}
                                    {{ Form::submit('Cancel request', array('class' => 'btn btn-primary cancelOrder')) }}
                                {{ Form::close() }}
                              @endif
                            </td>
                            @endhasrole
                          </tr>
                          @endforeach
                          @if(!count($leaves))
                            <tr class="no-rec">
                              <td colspan="4">No records!</td>
                            </tr>
                          @endif
                        </tbody>
                    </table>
                  {!! $leaves->appends(\Request::except('page'))->render() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
<script src="{{ asset('js/jquery-ui.min.js') }}" defer></script>
<script type="text/javascript">
$(function(){    
    $( "#from" ).datepicker({ 
                        dateFormat: 'dd-mm-yy',
                        minDate: 1
                     });
    $( "#to" ).datepicker({ 
                        dateFormat: 'dd-mm-yy',
                        minDate: 1
                     });
});
</script>
@endsection