<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => ['revalidate']], function () {
	Route::get('/', 'GuestController@index');
	Route::get('/product/{productName}/{productId}', 'GuestController@singleProduct');
	Route::get('/shop', 'GuestController@products');

	Route::get('/services', 'GuestController@services');
	Route::get('/about-us', 'GuestController@about');
	Route::get('/contact', 'GuestController@contact');

	Route::get('/cart', 'GuestController@showCart')->name('cart');
	Route::post('/cart/{id}', 'GuestController@addToCart');
	Route::put('/cart/update-quantity', 'GuestController@updateQty');
	Route::put('/cart/remove', 'GuestController@removeCartItem');

	Route::get('/cron', 'GuestController@cron');
});

Auth::routes();

Route::group(['middleware' => ['auth', 'revalidate']], function () {
	Route::get('/change-password','UserController@showChangePasswordForm');
	Route::post('/change-password','UserController@changePassword')->name('change-password');

	Route::get('/my-profile','UserController@myProfile');
	Route::get('/edit-profile','UserController@showEditProfileForm');
	Route::post('/edit-profile','UserController@editProfile')->name('edit');

	Route::put('/cart/checkout', 'GuestController@checkout');

	Route::get('/orders', 'UserController@orders');
	Route::get('/order-details/{id}', 'UserController@orderDetails');

	Route::put('/order-details', 'UserController@leaveReview');

	Route::get('/leaves', 'UserController@leaves');
	Route::put('/apply-for-leave', 'UserController@applyLeave');
	Route::post('/leave/toggle/{id}', 'UserController@toggle');

	Route::put('/order/changeItemStatus/{id}', 'UserController@changeItemStatus');
	Route::put('/order/refund/{id}', 'UserController@refund');
	Route::put('/pay-invoice', 'UserController@payInvoice');
});

//Customers
Route::group(['middleware' => ['role:customer', 'revalidate']], function () {
	//Route::get('/home', 'HomeController@index')->name('home');
});

//Workers
Route::group(['middleware' => ['role:worker', 'revalidate']], function () {
	Route::get('/worker', 'WorkerController@index');
	Route::get('/service-requests', 'WorkerController@serviceRequests');
	Route::get('/service-requests/{id}', 'WorkerController@serviceRequest');
	Route::put('/save-invoice', 'WorkerController@saveInvoice');
	Route::put('/update-schedule/{id}', 'WorkerController@updateSchedule');
	Route::put('/cancel-leave/{id}', 'WorkerController@cancelLeave');
});

//Admin
Route::group(['middleware' => ['role:admin', 'revalidate']], function () {
	Route::get('/admin', 'AdminController@index');
	Route::get('/admin/users', 'AdminController@users')->name('admin.users');
	Route::get('/admin/workers', 'AdminController@workers')->name('admin.workers');
	Route::post('/admin/disable/{id}', 'AdminController@disable');
	Route::get('/admin/approve-worker/{id}', 'AdminController@approveWorker');

	Route::resource('products', 'ProductController');
	Route::post('/products/disable/{id}', 'ProductController@disable');

	Route::resource('product-categories', 'ProductCategoryController');
	Route::post('/product-categories/disable/{id}', 'ProductCategoryController@disable');

	Route::resource('service-categories', 'ServiceCategoryController');
	Route::get('service-categories/subcategories/list', 'ServiceCategoryController@subcategories');
	Route::get('service-categories/create/{slug?}', 'ServiceCategoryController@create');
	Route::get('service-categories/{id}/edit/{slug?}', 'ServiceCategoryController@edit');
	Route::post('/service-categories/disable/{id}', 'ServiceCategoryController@disable');

	Route::resource('districts', 'DistrictController');
	Route::post('/districts/disable/{id}', 'DistrictController@disable');

	Route::resource('security-questions', 'SecQuestionController');
	Route::post('/security-questions/disable/{id}', 'SecQuestionController@disable');

	Route::get('/profile/{id}','AdminController@userProfile');

	Route::get('/reviews', 'AdminController@reviews');
	Route::put('/review/toggle/{id}', 'AdminController@toggleReview');

	Route::put('/admin/save-settings', 'AdminController@saveSettings');

	Route::resource('service-slots', 'ServiceSlotController');
	Route::post('/service-slots/disable/{id}', 'ServiceSlotController@disable');

	Route::get('/commission', 'AdminController@commission');
});

