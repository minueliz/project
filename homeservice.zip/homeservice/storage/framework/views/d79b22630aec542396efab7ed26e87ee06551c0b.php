<?php $__env->startComponent('mail::message'); ?>
Dear <?php echo e($name); ?>,

Your account has been approve by Administrator. You may now login by clicking on the below link.

<?php $__env->startComponent('mail::button', ['url' => url('/')]); ?>
Login
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
