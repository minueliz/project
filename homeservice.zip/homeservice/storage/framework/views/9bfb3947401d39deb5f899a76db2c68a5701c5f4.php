<?php $__env->startComponent('mail::message'); ?>
Dear <?php echo e($name); ?>,

User <b><?php echo e($service->worker->name); ?></b> has rejected the service request, #<b><a href="<?php echo e(URL::to('order-details/' . $service->order->id)); ?>"><?php echo e($service->order->id); ?></a></b>. 

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>