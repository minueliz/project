<?php $__env->startComponent('mail::message'); ?>
Dear <?php echo e($name); ?>,

Your leave for <?php echo e($duration); ?> has been <?php echo e($stat); ?> by Administrator.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
