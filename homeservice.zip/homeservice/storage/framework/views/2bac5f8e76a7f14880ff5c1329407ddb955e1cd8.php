<?php $__env->startSection('title', '| User Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(Request::is('profile/*') ? 'User' : 'My'); ?> Profile</div>

                <div class="card-body">
                  
                    <div class="form-group row">
                        <?php echo e(Form::label('name', 'Name', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e($userInfo->user->name); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <?php echo e(Form::label('addr', 'Address', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e($userInfo->addr); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                          <?php echo e(Form::label('did', 'District', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e($userInfo->district->district); ?>

                          </div>
                    </div>

                    <div class="form-group row">
                        <?php echo e(Form::label('pin_code', 'Pin code', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e($userInfo->pin_code); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <?php echo e(Form::label('phone', 'Phone', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e($userInfo->phone); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <?php echo e(Form::label('alt_phone', 'Alternate phone', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e(empty($userInfo->alt_phone)?'-':$userInfo->alt_phone); ?>

                        </div>
                    </div>
                  <?php if($worker): ?>
                    <div class="form-group row">
                        <?php echo e(Form::label('scat', 'Service category', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e($userInfo->category->category); ?>

                        </div>
                    </div>
                  <?php endif; ?>
                    <div class="form-group row">
                          <?php echo e(Form::label('sec_q', 'Security question', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e($userInfo->sec_question->question); ?>

                          </div>
                    </div>

                    <div class="form-group row">
                        <?php echo e(Form::label('sec_a', 'Answer', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e($userInfo->sec_a); ?>

                        </div>
                    </div>
                    
                    <?php if(!empty($userInfo->img)): ?>
                      <div class="form-group row">
                        <?php echo e(Form::label('sec_a', 'Profile image', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <img class="profilepic" src="<?php echo e(URL::asset('images/profile')); ?>/<?php echo e($userInfo->img); ?>">
                        </div>
                      </div>
                    <?php endif; ?>
                    
                    <?php if($worker): ?>
                      <div class="form-group row">
                        <?php echo e(Form::label('sec_a', 'Experience proof', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <a target="_blank" href="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($userInfo->exp_proof); ?>">
                            <img class="profilepic" src="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($userInfo->exp_proof); ?>">
                          </a>
                        </div>
                      </div>
                    
                      <div class="form-group row">
                        <?php echo e(Form::label('sec_a', 'Address proof', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <a target="_blank" href="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($userInfo->id_proof); ?>">
                            <img class="profilepic" src="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($userInfo->id_proof); ?>">
                          </a>
                        </div>
                      </div>

                      <div class="form-group row">
                        <?php echo e(Form::label('amt', 'Per hour amount', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e(number_format($userInfo->per_hour_amount, 2)); ?>

                        </div>
                      </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>