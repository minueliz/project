<?php $__env->startSection('title', '| Edit Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <h1>Products</h1>
            <div class="row">
            	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<div class="col-md-3 singleProd">
            	  <div class="w-100 prod-list-img">
					  <?php if(!empty($product->img)): ?>
		                  <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($product->img); ?>" >
		              <?php else: ?>
		                  <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/214x150.png" >
		              <?php endif; ?>
		          </div>  
				  <div class="product-short">
				    <h5 class="prod-title"><?php echo e($product->name); ?></h5>
				    <h6 class="prod-desc"><?php echo e(ucfirst((strlen($product->description) > 70)?substr($product->description, 0, 70).'...':$product->description)); ?></h6>
				    <div class="w-100 clearfix">
				    	<span class="prod-amount"><?php echo e(config('app.currency')); ?> <?php echo e(number_format($product->amount, 2)); ?></span>
				    	<?php echo e(Form::open(array('url' => 'cart/' . $product->id, 'class' => 'pull-right'))); ?>

                          <?php echo e(Form::hidden('_method', 'POST')); ?>

                          
                              <?php echo e(Form::submit('Buy', array('class' => 'btn btn-primary float-right'))); ?>


                        <?php echo e(Form::close()); ?>

				    </div>
				  </div>
				</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          	</div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>