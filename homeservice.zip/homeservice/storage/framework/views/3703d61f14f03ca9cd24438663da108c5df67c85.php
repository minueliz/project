<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
          <div class="col-md-3">
              <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
        <div class="col-md-9">
        <?php else: ?>
        <div class="col-md-12">
        <?php endif; ?>
            <div class="card">
              <?php if(auth()->check() && auth()->user()->hasRole('worker')): ?>
                <div class="card-header">
                  Apply for leave
                </div>

                <div class="card-body">
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                      <?php echo e(Html::ul($errors->all())); ?>

                    </div>
                  <?php endif; ?>
                  <?php if(session('success')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('success')); ?>

                      </div>
                  <?php endif; ?> 

                  <?php echo e(Form::model(null, array('url' => array('apply-for-leave'), 'method' => 'PUT'))); ?>

                    <fieldset>

                      <div class="form-group row">
                          <?php echo e(Form::label('from', 'From Date', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('from', Request::old('from'), array('class' => 'form-control'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('to', 'To Date', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('to', Request::old('to'), array('class' => 'form-control'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                            <?php echo e(Form::label('reason', 'Reason', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                            <div class="col-md-4">
                              <?php echo e(Form::textarea('reason', Request::old('reason'), array('class' => 'form-control', 'rows' => '3'))); ?>

                            </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          <?php echo e(Form::submit('Apply', array('class' => 'btn btn-primary'))); ?>

                        </div>
                      </div>
                    </fieldset>
                  <?php echo e(Form::close()); ?>


                  <h4>History</h4>
                <?php else: ?>
                  <div class="card-header">
                    Leave applications
                  </div>
                <?php endif; ?>
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                            <th>Name<th>
                          <?php endif; ?>
                          <th scope="col">From</th>
                          <th scope="col">To</th>
                          <th scope="col">Reason</th>
                          <th scope="col">Status</th>
                          <th scope="col"></th>
                        </tr>
                      </thead>
                      <tbody>                        
                          <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                              <td>
                                <a href="<?php echo e(URL::to('profile/' . $leave->user->id)); ?>"><?php echo e($leave->user->name); ?></a>
                              <td>
                            <?php endif; ?>
                            <td>
                              <?php echo e(date('d-m-Y', strtotime($leave->from))); ?>

                            </td>
                            <td>
                              <?php echo e(date('d-m-Y', strtotime($leave->to))); ?>

                            </td>
                            <td><?php echo nl2br($leave->reason); ?></td>
                            <td><span class="<?php echo e(($leave->status == 1)?'btn alert-secondary':(($leave->status == 2)?'btn alert-primary':'btn alert-danger')); ?>"><?php echo e($status[$leave->status]); ?></span></td>
                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                              <td>
                                <?php if($leave->status == 1): ?>
                                  <?php echo e(Form::open(array('url' => 'leave/toggle/' . $leave->id, 'class' => 'pull-right'))); ?>

                                    <?php echo e(Form::hidden('_method', 'POST')); ?>

                                      <?php echo e(Form::submit('Approve', array('class' => 'btn btn-sm btn-primary', 'name' => 'action'))); ?>

                                      <?php echo e(Form::submit('Decline', array('class' => 'btn btn-sm btn-dark', 'name' => 'action'))); ?>

                                  <?php echo e(Form::close()); ?>

                                <?php endif; ?>
                              </td>
                            <?php else: ?>
                            <td>
                              <?php if(\App\Http\Controllers\UserController::canCancelLeave($leave)): ?>
                                <?php echo e(Form::open(array('url' => 'cancel-leave/'.$leave->id))); ?>

                                    <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                    <?php echo e(Form::hidden('status', '6')); ?>

                                    <?php echo e(Form::submit('Cancel request', array('class' => 'btn btn-primary cancelOrder'))); ?>

                                <?php echo e(Form::close()); ?>

                              <?php endif; ?>
                            </td>
                            <?php endif; ?>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if(!count($leaves)): ?>
                            <tr class="no-rec">
                              <td colspan="4">No records!</td>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                    </table>
                  <?php echo $leaves->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>" defer></script>
<script type="text/javascript">
$(function(){    
    $( "#from" ).datepicker({ 
                        dateFormat: 'dd-mm-yy',
                        minDate: 1
                     });
    $( "#to" ).datepicker({ 
                        dateFormat: 'dd-mm-yy',
                        minDate: 1
                     });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>