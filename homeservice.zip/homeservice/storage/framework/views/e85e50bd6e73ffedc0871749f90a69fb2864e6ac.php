<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Products</div>

                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?> 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col">Cateogry</th>
                          <th scope="col">Quantity</th>
                          <th scope="col">Amount</th>
                          <th scope="col" width="100px"></th>
                          <th scope="col" width="144px">Action</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td>
                                <a href="<?php echo e(URL::to('products/' . $product->id)); ?>"><?php echo e($product->name); ?></a>
                              </td>
                              <td><?php echo e($product->category->category); ?></td>
                              <td><?php echo e($product->qty); ?></td>
                              <td><?php echo e(number_format($product->amount, 2)); ?></td>
                              <td>
                                <?php if(!empty($product->img)): ?>
                                  <img class="productpic" src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($product->img); ?>">
                                <?php endif; ?>
                              </td>
                              <td>
                                <a class="btn btn-sm btn-info approve-btn" href="<?php echo e(URL::to('products/' . $product->id . '/edit')); ?>">Edit</a>
                                <?php echo e(Form::open(array('url' => 'products/disable/' . $product->id, 'class' => 'pull-right'))); ?>

                                    <?php echo e(Form::hidden('_method', 'POST')); ?>

                                    
                                        <?php echo e(Form::submit(($product->status)?'Disable':'Enable', array('class' => ($product->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary'))); ?>


                                  <?php echo e(Form::close()); ?>                                
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if(!count($products)): ?>
                            <tr class="no-rec">
                              <td colspan="5">No records!</td>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                    </table>
                  <?php echo $products->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>