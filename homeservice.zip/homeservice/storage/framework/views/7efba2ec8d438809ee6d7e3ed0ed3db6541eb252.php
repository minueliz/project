<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                  Reviews
                </div>

                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?> 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Order #ID</th>
                          <th scope="col">User</th>
                          <th scope="col" width="106px">Date</th>
                          <th scope="col">Comment</th>
                          <th scope="col" width="120px">Rating</th>
                          <th scope="col">Product</th>
                          <th scope="col">Worker</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>                        
                          <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td>
                              <a href="<?php echo e(URL::to('order-details/' . $review->orderItem->order_id)); ?>">#<?php echo e(str_pad($review->orderItem->order_id, 4, '0', STR_PAD_LEFT)); ?></a>
                            </td>
                            <td>
                              <?php echo e($review->user->name); ?>

                            </td>
                            <td>
                              <?php echo e(date('d-m-Y', strtotime($review->created_at))); ?>

                            </td>
                            <td>
                              <?php echo nl2br($review->comment); ?>

                            </td>
                            <td>
                              <?php for($i=$review->rating; $i<5; $i++): ?>
                                <span><span class="text-warning far fa-star" aria-hidden="true"></span></span>
                              <?php endfor; ?>
                              <?php for($i=1; $i<=$review->rating; $i++): ?>
                                <span><i class="text-warning fa fa-star"></i></span>
                              <?php endfor; ?>
                            </td>
                            <td>
                              <?php echo e(($review->product_id)?$review->product->name:'--'); ?>

                            </td>
                            <td>
                              <?php echo e(($review->worker_id)?$review->worker->name:'--'); ?>

                            </td>
                            <td>
                              <?php echo e(Form::open(array('url' => 'review/toggle/' . $review->id, 'class' => 'pull-right'))); ?>

                                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                    <?php echo e(Form::submit(($review->status)?'Disable':'Enable', array('class' => ($review->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary'))); ?>

                              <?php echo e(Form::close()); ?> 
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if(!count($reviews)): ?>
                            <tr class="no-rec">
                              <td colspan="7">No records!</td>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                    </table>
                  <?php echo $reviews->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>