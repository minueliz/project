<?php $__env->startSection('title', '| Edit Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <h1>Items in Your Cart</h1>
            <div class="cart-list col-md-12">
            	<!-- if there are creation errors, they will show here -->
				<?php if($errors->any()): ?>
					<div class="alert alert-danger">
					  <?php echo e(Html::ul($errors->all())); ?>

					</div>
				<?php endif; ?>
            	<table class="table table-responsive">
            	<?php $__currentLoopData = $cartCon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					
            	  <tr>
            	  	<td class="prod-list-img">
						  <?php if(!empty($con->model->img)): ?>
			                  <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($con->model->img); ?>" >
			              <?php else: ?>
			                  <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/214x150.png" >
			              <?php endif; ?>
			        </td>
			        <td>				        						  
					    <h5 class="prod-title"><?php echo e($con->name); ?></h5>
					    <h6 class="prod-desc"><?php echo e(ucfirst((strlen($con->model->description) > 170)?substr($con->model->description, 0, 170).'...':$con->model->description)); ?></h6>
					</td>
					<td width="100px">
					  	<?php echo e(Form::open(array('url' => 'cart/update-quantity', 'class' => 'pull-right'))); ?>

	                      <?php echo e(Form::hidden('_method', 'PUT')); ?>

	                      <?php echo e(Form::hidden('rowId', $con->rowId)); ?>

	                      <?php echo e(Form::text('qty', $con->qty, array('class' => 'form-control', 'minlength' => 1, 'maxlength' => '3'))); ?>

	                      <?php echo e(Form::submit('Update', array('class' => 'btn btn-sm btn-secondary mt-1'))); ?>

	                    <?php echo e(Form::close()); ?>

					</td>
					<td width="150px">
					  <div class="prod-amount"><?php echo e(config('app.currency')); ?> <?php echo e(number_format(($con->price*$con->qty), 2)); ?></div>
					</td>
					<td>
					  <?php echo e(Form::open(array('url' => 'cart/remove', 'class' => 'pull-right'))); ?>

	                      <?php echo e(Form::hidden('_method', 'PUT')); ?>

	                      <?php echo e(Form::hidden('rowId', $con->rowId)); ?>

	                      <?php echo e(Form::submit('Remove', array('class' => 'btn btn-sm btn-danger'))); ?>

	                  <?php echo e(Form::close()); ?>

					</td>
				  </tr>					
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	<?php if(count($cartCon)): ?>
	            	<tr>
	            		<td colspan="5">
	            			<?php echo e(Form::open(array('url' => 'cart/checkout', 'class' => 'float-right'))); ?>

		                      <?php echo e(Form::hidden('_method', 'PUT')); ?>

		                      <?php echo e(Form::submit('Check Out', array('class' => 'btn btn-sm btn-primary'))); ?>

		                  	<?php echo e(Form::close()); ?>

	            		</td>
	            	</tr>
	            <?php else: ?>
	            	<tr>
	            		<td colspan="5">
	            			Your Cart is Empty!
	            		</td>
	            	</tr>
	            <?php endif; ?>
            	</table>
          	</div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
$(function(){
	$("input[type='text']").on("input", function() {
	 	$(this).next().show();
	});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>