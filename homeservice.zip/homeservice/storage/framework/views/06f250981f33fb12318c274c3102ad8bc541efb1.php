<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  Service Requests
                </div>

                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?> 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th></th>
                          <th scope="col">Customer</th>
                          <th scope="col" width="106px">Service Date</th>
                          <th scope="col">Category</th>
                          <th scope="col">Slot</th>
                          <th scope="col">Commision</th>
                          <th scope="col">Amount</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>                        
                          <?php $__currentLoopData = $serviceRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td>
                              <a href="<?php echo e(URL::to('service-requests/' . $order->id)); ?>">#<?php echo e(str_pad($order->id, 4, '0', STR_PAD_LEFT)); ?></a>
                            </td>
                            <td>
                              <?php echo e($order->order->user->name); ?>

                            </td>
                            <!-- <td>
                              <?php echo e($order->order->user->userinformation->phone); ?><br>
                              <?php if(!empty($order->order->user->userinformation->phone)): ?>
                                <?php echo e($order->order->user->userinformation->alt_phone); ?>

                              <?php endif; ?>
                            </td> -->
                            <td>
                              <?php echo e(date('d-m-Y', strtotime($order->service_slot_from))); ?>

                            </td>
                            <td>
                              <?php echo e($order->worker->userinformation->category->category); ?>

                            </td>
                            <!-- <td>
                              <?php echo e($order->serviceSubCat->category); ?>

                            </td> -->
                            <td>
                              <?php echo e(date('H:i', strtotime($order->service_slot_from))); ?> - 
                              <?php echo e(date('H:i', strtotime($order->service_slot_to))); ?>

                            </td>
                            <!-- <td>
                              <?php echo nl2br($order->order->service_addr); ?>  
                            </td> -->
                            <td><?php echo config('app.currency'); ?><?php echo e(number_format($order->commision, 2)); ?></td>
                            <td><?php echo config('app.currency'); ?><?php echo e(number_format(($order->amount - $order->commision), 2)); ?></td>
                            <td class="genInvoice">
                              <?php if(\App\Http\Controllers\WorkerController::canGenInvoice($order)): ?>
                                <a href="#" class="d-block btn btn-template-main btn-sm invoiceModal" data-toggle="modal" data-target="#invoiceModal" data-itemId="<?php echo e($order->id); ?>" data-for="<?php echo e($order->order->user->name); ?>">Generate<br>invoice</a>
                              <?php elseif(\App\Http\Controllers\WorkerController::canRequestPayment($order)): ?>
                                <?php echo e(Form::open(array('url' => 'order/changeItemStatus/'.$order->id))); ?>

                                    <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                    <?php echo e(Form::hidden('status', '9')); ?>

                                    <?php echo e(Form::hidden('type', 'refund')); ?>

                                    <?php echo e(Form::submit('Request refund', array('class' => 'btn btn-primary cancelOrder'))); ?>

                                <?php echo e(Form::close()); ?>

                              <?php else: ?>
                                <?php echo e($servStatuses[$order->status]); ?>

                              <?php endif; ?>
                            </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if(!count($serviceRequests)): ?>
                            <tr class="no-rec">
                              <td colspan="8">No records!</td>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                    </table>
                  <?php echo $serviceRequests->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php echo e(Form::open(array('url' => 'save-invoice/', 'class' => "invoiceForm", 'method' => "POST"))); ?>

    <?php echo e(Form::hidden('_method', 'PUT')); ?>

    <?php echo e(Form::hidden('itemId', '')); ?>

    <div class="modal" tabindex="-1" role="dialog" id="invoiceModal">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title"></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="form-group row">
              <div class="col-md-4">
                <?php echo e(Form::label('hours', 'Additional hours', array('class' => 'col-md-4 control-label text-md-right'))); ?>

              </div>  
              <div class="col-md-4">
                <?php echo Form::select('hours', [
                  0 => 0,
                  1 => 1,
                  2 => 2,
                  3 => 3,
                  4 => 4
                ], null, ['class' => 'form-control']); ?>

              </div>
              <div class="col-md-4">
                    <span class="subTotal"></spam>
                  </div>
              </div>
              <div class="form-group row">
                <div class="col-md-4">
                  <?php echo e(Form::label('additional', 'Additional purchases', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                </div>
                <div class="col-md-4">
                  <?php echo e(Form::textarea('additional', Request::old('additional'), array('class' => 'form-control', 'rows' => '3'))); ?>

                </div>
                <div class="col-md-2 addAmt">
                  <?php echo config('app.currency'); ?><?php echo e(Form::text('additionalAmt', Request::old('additionalAmt'), array('class' => 'form-control float-right', 'maxLength' => 5))); ?>

                </div>
              </div>
            </div>
            <div class="form-group row">
              <div class="col-md-2 offset-md-8">
                <span class="total"></span>
              </div>
            </div>
            <div class="alert alert-warning dis-none"></div>
          
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Generate invoice</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
$(function(){
  $('.invoiceModal').click(function(){
        $('#invoiceModal .modal-title').html('Generate invoice for ' + $(this).attr('data-for'));
        $('input[name="itemId"]').val($(this).attr('data-itemId'));
        $('.subTotal').empty(); $('.total').empty();
        $('select[name="hours"]').val(0).trigger('change')
  })

  $('.invoiceForm').on('submit', function(){ 
    /*if((parseInt($('select[name="hours"]').val() * <?php echo e(Auth::User()->userinformation->per_hour_amount); ?>) + parseInt($('input[name="additionalAmt"]').val()?$('input[name="additionalAmt"]').val():0)) == 0) {
      $('.invoiceForm .alert').html('Please enter the details');
      $('.invoiceForm .alert').show();
      $('input[name="hours"]').focus()
      return false;
    }*/
    if(!confirm('Proceed with the invoice?'))
      return false;
  })

  $('select[name="hours"]').change(function(){
    $('.invoiceForm .alert').hide();
    $('.subTotal').html( '<?php echo config('app.currency'); ?>' + ($(this).val() * <?php echo e(Auth::User()->userinformation->per_hour_amount); ?>))

    $('.total').html( '<?php echo config('app.currency'); ?>' + (parseInt($(this).val() * <?php echo e(Auth::User()->userinformation->per_hour_amount); ?>) + parseInt($('input[name="additionalAmt"]').val()?$('input[name="additionalAmt"]').val():0)))
  })

  $('input[name="additionalAmt"]').keypress(function(e){
    if(! /^\d*$/.test(e.key)) {
      return false;
    }
  });

  $('input[name="additionalAmt"]').keyup(function(e){
    $('.invoiceForm .alert').hide();
    $('.total').html( '<?php echo config('app.currency'); ?>' + (parseInt($('select[name="hours"]').val() * <?php echo e(Auth::User()->userinformation->per_hour_amount); ?>) + parseInt($('input[name="additionalAmt"]').val()?$('input[name="additionalAmt"]').val():0)))
  });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>