<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Wrokers</div>

                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?> 
                    <table class="table table-hover table-striped table-responsive-xl">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col">Address</th>
                          <th scope="col">District</th>
                          <th scope="col">Phone</th>
                          <th scope="col">Category</th>
                          <th scope="col">Exp. cert.</th>
                          <th scope="col">ID proof</th>
                          <th scope="col">Per hour amount</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>                        
                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td>
                                <a href="<?php echo e(URL::to('profile/' . $user->id)); ?>"><?php echo e($user->name); ?></a>
                              </td>
                              <td><?php echo e($user->addr); ?></td>
                              <td><?php echo e($user->district); ?></td>
                              <td><?php echo e($user->phone); ?></td>
                              <td><?php echo e($user->category); ?></td>
                              <td>
                                <a target="_blank" href="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($user->exp_proof); ?>">
                                  <img src="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($user->exp_proof); ?>" class="proofs">
                                </a>
                              </td>
                              <td>
                                <a target="_blank" href="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($user->id_proof); ?>">
                                  <img src="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($user->id_proof); ?>" class="proofs">
                                </a>
                              </td>
                              <td><?php echo e(number_format($user->per_hour_amount, 2)); ?></td>
                              <td>
                                <?php if(!$user->worker_approved): ?>
                                  <a class="btn btn-sm btn-info approve-btn" href="<?php echo e(URL::to('admin/approve-worker/' . $user->id)); ?>">Approve</a>
                                <?php endif; ?>
                                <?php echo e(Form::open(array('url' => 'admin/disable/' . $user->id, 'class' => 'pull-right'))); ?>

                                  <?php echo e(Form::hidden('_method', 'POST')); ?>

                                  
                                      <?php echo e(Form::submit(($user->status)?'Disable':'Enable', array('class' => ($user->status)?'btn btn-sm btn-warning':'btn btn-sm btn-primary'))); ?>


                                <?php echo e(Form::close()); ?>

                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  <?php echo $users->appends(\Request::except('page'))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>