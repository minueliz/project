<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
            <div class="col-md-3">
                <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        <div class="col-md-9">
        <?php else: ?>
        <div class="col-md-12">
        <?php endif; ?>
            <div class="card">
                <div class="card-header">Order Details</div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row" id="customer-order">
                      <div class="col-md-3 mb-3">
                        Date: <b><?php echo e(date('d-m-Y', strtotime($order->created_at))); ?></b>
                      </div>
                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>             
                      <div class="col-md-3 mb-3">
                        Name: <b><?php echo e($order->user->name); ?></b>
                      </div>
                    <?php endif; ?>
                      <br>
                    <?php if(count($prods)): ?>
                      <h4 class="w-100 pl-3">Products</h4>
                      <table class="table">
                        <thead>
                            <tr>
                                <th colspan="2">Product</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Unit price</th>
                                <th width="100px">Total</th>
                                <th width="156px">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr>
                                    <td>
                                        <?php if(!empty($item->product->img)): ?>
                                            <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($item->product->img); ?>" >
                                        <?php else: ?>
                                            <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/214x150.png" >
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($item->product->name); ?>

                                        <?php if($item->status == 3): ?>
                                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                            <?php else: ?>
                                                <?php if(\App\Http\Controllers\UserController::alreadyReviewed($item->id)): ?>
                                                    <a class="d-block btn btn-template-main btn-sm reviewModal" data-toggle="modal" data-target="#reviewModal" data-for="Product, <?php echo e($item->product->name); ?>" data-product="<?php echo e($item->product->id); ?>" data-item="<?php echo e($item->id); ?>" data-type="1"><?php echo e(__('Leave review')); ?></button>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($item->product->category->category); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->qty); ?>

                                    </td>
                                    <td>
                                        <?php echo config('app.currency'); ?><?php echo e(number_format($item->amount, 2)); ?>

                                    </td>
                                    <td>
                                        <?php echo config('app.currency'); ?><?php echo e(number_format($item->qty * $item->amount, 2)); ?>

                                    </td>
                                    <td>
                                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                        <?php echo e(Form::open(array('url' => 'order/changeItemStatus/'.$item->id))); ?>

                                            <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                            <?php echo Form::select('status', $prodStatuses, $item->status, ['class' => 'form-control status']); ?>

                                        <?php echo e(Form::close()); ?>

                                    <?php else: ?>
                                        <?php if($item->status == 1): ?>
                                            <?php echo e(Form::open(array('url' => 'order/changeItemStatus/'.$item->id))); ?>

                                                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                                <?php echo e(Form::hidden('_for', '1')); ?>

                                                <?php echo e(Form::hidden('status', '6')); ?>

                                                <?php echo e(Form::submit('Cancel order', array('class' => 'btn btn-primary cancelOrder'))); ?>

                                            <?php echo e(Form::close()); ?>

                                        <?php endif; ?> 
                                        <?php echo e($prodStatuses[$item->status]); ?>

                                    <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                      </table>
                    <?php endif; ?>
                    <?php if(count($servs)): ?>
                      <h4 class="w-100 pl-3 mt-3">Services</h4>
                      <table class="table">
                        <thead>
                            <tr>
                                <th colspan="2">Service</th>
                                <th>Category</th>
                                <th>For date</th>
                                <th>Per hour amount</th>
                                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                    <th>Commision</th>
                                <?php endif; ?>
                                <th width="100px">Total</th>
                                <th width="156px">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $servs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr>
                                    <td>
                                        <?php if(!empty($item->product->img)): ?>
                                            <img class="img-responsive" src="<?php echo e(URL::asset('images/profile')); ?>/<?php echo e($item->product->img); ?>" >
                                        <?php else: ?>
                                            <img class="img-responsive" src="<?php echo e(URL::asset('images/products')); ?>/214x150.png" >
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($item->worker->name); ?>

                                        <?php if($item->status == 5): ?>
                                            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                            <?php else: ?>
                                                <?php if(\App\Http\Controllers\UserController::alreadyReviewed($item->id)): ?>
                                                    <a class="d-block btn btn-template-main btn-sm reviewModal" data-toggle="modal" data-target="#reviewModal" data-for="Service of, <?php echo e($item->worker->name); ?>" data-worker="<?php echo e($item->worker->id); ?>" data-item="<?php echo e($item->id); ?>" data-type="2"><?php echo e(__('Leave review')); ?></button>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($item->worker->userinformation->category->category); ?>

                                        <br>
                                        <?php echo e($item->serviceSubCat->category); ?>

                                    </td>
                                    <td>                                        
                                        <?php echo e(date('d-m-Y', strtotime($item->service_slot_from))); ?><br>
                                        <?php echo e(date('H:i', strtotime($item->service_slot_from))); ?> - 
                                        <?php echo e(date('H:i', strtotime($item->service_slot_to))); ?>

                                    </td>
                                    <td>
                                        <?php echo config('app.currency'); ?>

                                        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                            <?php echo e(number_format(($item->worker->userinformation->per_hour_amount - $item->commision), 2)); ?>

                                        <?php else: ?>
                                            <?php echo e(number_format($item->worker->userinformation->per_hour_amount, 2)); ?>

                                        <?php endif; ?>
                                    </td>
                                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                        <td>
                                            <?php echo config('app.currency'); ?><?php echo e(number_format($item->commision, 2)); ?>

                                        </td>
                                    <?php endif; ?>
                                    <td>
                                        <?php echo config('app.currency'); ?><?php echo e(number_format($item->amount, 2)); ?>

                                    </td>
                                    <td>
                                        <?php if(auth()->check() && auth()->user()->hasRole('customer')): ?>
                                            <?php if($item->status == 0): ?>
                                                <?php echo e($servStatuses[$item->status]); ?>

                                                <br>
                                                <?php echo e(Form::open(array('url' => 'order/changeItemStatus/'.$item->id))); ?>

                                                    <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                                    <?php echo e(Form::hidden('status', '6')); ?>

                                                    <?php echo e(Form::hidden('_serC', '1')); ?>

                                                    <?php echo e(Form::submit('Cancel order', array('class' => 'btn btn-primary cancelOrder'))); ?>

                                                <?php echo e(Form::close()); ?> 
                                            <?php elseif($item->status == 7): ?>
                                                <a class="pay" href="#" data-hours="<?php echo e($item->qty); ?>" data-amt="<?php echo e($item->commision); ?>" data-item="<?php echo e($item->id); ?>" data-per="<?php echo e($item->worker->userinformation->per_hour_amount); ?>" data-initial="true">Pay for service<a/>
                                            <?php elseif($item->status == 4): ?>
                                                <a class="pay" href="#" data-hours="<?php echo e($item->invoice->hours); ?>" data-additional-purchases="<?php echo ($item->invoice->additional_purchases)?nl2br($item->invoice->additional_purchases):'--'; ?>" data-amt="<?php echo e(($item->invoice->additional_amount)?$item->invoice->additional_amount:'--'); ?>" data-order="#<?php echo e($item->order->id); ?>" data-total="<?php echo e($item->amount + $item->invoice->commision - $item->commision); ?>" data-per="<?php echo e($item->worker->userinformation->per_hour_amount); ?>" data-invoice="<?php echo e($item->invoice->id); ?>" data-initial="false">Pay invoice<a/>
                                            <?php else: ?>
                                                <?php echo e($servStatuses[$item->status]); ?>

                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php echo e($servStatuses[$item->status]); ?>

                                        <?php endif; ?>
                                        <?php if(\App\Http\Controllers\UserController::canRequestRefund($item)): ?>
                                            <?php echo e(Form::open(array('url' => 'order/changeItemStatus/'.$item->id))); ?>

                                                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                                <?php echo e(Form::hidden('status', '8')); ?>

                                                <?php echo e(Form::hidden('type', 'refund')); ?>

                                                <?php echo e(Form::submit('Request refund', array('class' => 'btn btn-primary'))); ?>

                                            <?php echo e(Form::close()); ?> 
                                        <?php endif; ?>
                                        <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                            <?php echo e(Form::open(array('url' => 'order/refund/'.$item->id))); ?>

                                                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                                <?php echo e(Form::hidden('id', $item->id)); ?>

                                                <?php if($item->status == 8): ?>
                                                    <?php echo e(Form::submit('Refund commission to customer', array('class' => 'btn btn-primary split'))); ?>

                                                <?php elseif($item->status == 9): ?>
                                                    <?php echo e(Form::submit('Release payment to worker', array('class' => 'btn btn-primary split'))); ?>

                                                <?php endif; ?>
                                            <?php echo e(Form::close()); ?> 
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php if($item->status == 5): ?>
                                    <tr>
                                        <td>Additional purchases: <?php echo e(($item->invoice->additional_purchases)?$item->invoice->additional_purchases:'--'); ?></td>
                                        <td>Additional amount: <?php echo config('app.currency'); ?><?php echo e(number_format($item->invoice->additional_amount, 2)); ?></td>
                                        <td <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?> colspan="4" <?php else: ?> colspan="3" <?php endif; ?> class="text-right">Additional hours: <?php echo e($item->invoice->hours); ?></td>
                                        <td colspan="3" class="text-left"><?php echo config('app.currency'); ?><?php echo e($item->invoice->total); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                      </table>
                    <?php endif; ?>
                    <table class="table w-100">
                        <tr>
                            <td colspan="4" class="text-right">Total: </td>
                            <td class="totalCartC" width="256px"><?php echo config('app.currency'); ?><?php echo e(number_format($order->amount, 2)); ?></td>
                        </tr>
                    </table>
                    <?php if(!is_null($order->shipping_address)): ?>
                        <div class="col-sm-4">
                            <h4>Shipping address</h4>
                            <p><?php echo nl2br($order->shipping_address); ?></p>
                        </div>
                    <?php endif; ?>  
                    <?php if(!is_null($order->service_addr)): ?>
                        <div class="col-sm-4">
                            <h4>Service address</h4>
                            <p><?php echo nl2br($order->service_addr); ?></p>
                        </div>
                    <?php endif; ?>

                    <!-- Pay invoice -->
                    <?php echo e(Form::open(array('url' => 'pay-invoice', 'class' => 'float-right w-100 dis-none paymentForm'))); ?>

                        <?php echo e(Form::hidden('_method', 'PUT')); ?>

                        <?php echo e(Form::hidden('_invoice', '')); ?>

                        <?php echo e(Form::hidden('_item', '')); ?>

                        <div class="col-md-12 mb-5">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"></h3>
                                </div>
                                <!-- if there are creation errors, they will show here -->
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger hideIf">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo $error; ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-md-3 text-right updateText"></div>
                                    <div class="col-md-3"><b><span class="aHours"></b></div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 text-right">Per hour amount: </div>
                                    <div class="col-md-3"><b><span class="per"></b></div>
                                </div>
                                <div class="row hide">
                                    <div class="col-md-3 text-right">Additional purchases: </div>
                                    <div class="col-md-3"><b><span class="aP"></b></div>
                                </div>
                                <div class="row mb-2 hide">
                                    <div class="col-md-3 text-right">Additional purchase amount: </div>
                                    <div class="col-md-3"><b><span class="aPA"></b></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-3 text-right">Total: </div>
                                    <div class="col-md-3"><b><span class="total"></b></div>
                                </div>
                                <div class="panel-body col-md-4 row">
                                    <div class="form-group w-100">
                                        <label for="cardName">
                                            Name on Card</label>
                                        <div class="input-group">
                                            <?php echo e(Form::text('cardName', Request::old('cardName'), array('class' => 'form-control', 'placeholder' => "", 'required'))); ?>

                                        </div>
                                    </div>

                                    <div class="form-group w-100">
                                        <label for="cardNumber">
                                            Card Number</label>
                                        <div class="input-group">
                                            <?php echo e(Form::text('cardNumber', Request::old('cardNumber'), array('class' => 'form-control', 'placeholder' => "4800 1234 5678 9876", 'required', 'minlength' => 14, 'maxlength' => 16))); ?>

                                            <span class="input-group-addon"><span class="fa fa-lock"></span></span>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12">
                                            <div class="form-group">
                                                <label for="expiry">
                                                    Card Type</label>
                                                <div class="col-xs-6 col-lg-6 pl-ziro">
                                                    <?php echo Form::select('cardType', $cardTypes, Request::old('cardType'), ['class' => 'form-control']); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xs-7 col-md-7">
                                            <div class="form-group">
                                                <label for="expiry">
                                                    Expiry Date</label>
                                                <div class="col-xs-6 col-lg-6 pl-ziro">
                                                    <?php echo e(Form::text('expiry', Request::old('expiry'), array('class' => 'form-control', 'placeholder' => "MM/YY", 'required', 'maxlength' => 5 ))); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xs-5 col-md-5 pull-right">
                                            <div class="form-group">
                                                <label for="cvCode">
                                                    CVV</label>
                                                <div class="col-xs-7 col-lg-7 pl-ziro">
                                                    <?php echo e(Form::text('cvv', Request::old('cvv'), array('class' => 'form-control', 'placeholder' => "CVV", 'minlength' => 3, 'maxlength' => 3, 'required', 'min' => 1 ))); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php echo e(Form::submit('Pay & Check Out', array('class' => 'btn btn-success btn-lg btn-block'))); ?>

                                </div>
                            </div>
                        </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>            
        </div>
    </div>
</div>
<?php echo e(Form::open(array('url' => 'order-details/', 'class' => "reviewForm"))); ?>

    <?php echo e(Form::hidden('_method', 'PUT')); ?>

    <?php echo e(Form::hidden('itemId', '')); ?>

    <?php echo e(Form::hidden('productId', '')); ?>

    <?php echo e(Form::hidden('workerId', '')); ?>

    <?php echo e(Form::hidden('rating', '')); ?>

    <div class="modal" tabindex="-1" role="dialog" id="reviewModal">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title"></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="form-group row">
                  <?php echo e(Form::label('comment', 'Comment', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                  <div class="col-md-6">
                    <?php echo e(Form::textarea('comment', Request::old('comment'), array('class' => 'form-control', 'rows' => '3'))); ?>

                  </div>
            </div>
            <section class='rating-widget offset-md-4 pl-2'>

              <!-- Rating Stars Box -->
              <div class='rating-stars'>
                <ul id='stars'>
                  <li class='star' title='Poor' data-value='1'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                  <li class='star' title='Fair' data-value='2'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                  <li class='star' title='Good' data-value='3'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                  <li class='star' title='Excellent' data-value='4'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                  <li class='star' title='WOW!!!' data-value='5'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                </ul>
              </div>
            </section>

            <div class="alert alert-warning dis-none"></div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Post review</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
$(function(){
    $(".status").change(function() {
        this.form.submit();
    });

    $('.status').each(function(){ 
        if($(this).val() > 1)
            for(var i=1; i<$(this).val(); i++) {
                $(this).children('option[value='+i+']').attr('disabled', true);
            } 
    })

    $('.reviewModal').click(function(){
        $('#reviewModal .modal-title').html('Leave review for ' + $(this).attr('data-for'));
        $('.reviewForm input[name="itemId"]').val($(this).attr('data-item'));
        if($(this).attr('data-type') == '1')
            $('.reviewForm input[name="productId"]').val($(this).attr('data-product'));
        else
            $('.reviewForm input[name="workerId"]').val($(this).attr('data-worker'));
    })

    /* 1. Visualizing things on Hover - See next part for action on click */
    $('#stars li').on('mouseover', function(){
        var onStar = parseInt($(this).data('value'), 10); // The star currently mouse on

        // Now highlight all the stars that's not after the current hovered star
        $(this).parent().children('li.star').each(function(e){
          if (e < onStar) {
            $(this).addClass('hover');
          }
          else {
            $(this).removeClass('hover');
          }
        });

    }).on('mouseout', function(){
        $(this).parent().children('li.star').each(function(e){
          $(this).removeClass('hover');
        });
    });


    /* 2. Action to perform on click */
    $('#stars li').on('click', function(){
        $('.reviewForm .alert').hide();

        var onStar = parseInt($(this).data('value'), 10); // The star currently selected
        var stars = $(this).parent().children('li.star');

        for (i = 0; i < stars.length; i++) {
          $(stars[i]).removeClass('selected');
        }

        for (i = 0; i < onStar; i++) {
          $(stars[i]).addClass('selected');
        }

        var ratingValue = parseInt($('#stars li.selected').last().data('value'), 10);
        $('.reviewForm input[name="rating"]').val(ratingValue)
    });

    $('input[name="comment"]').keypress(function(){
        $('.reviewForm .alert').hide()
    })

    $('.reviewForm').on('submit', function(){
        if($('textarea[name="comment"]').val() == "") {
            $('.reviewForm .alert').html('Please enter your comments');
            $('.reviewForm .alert').show();
            $('textarea[name="comment"]').focus()
            return false;
        }

        var ratingValue = parseInt($('#stars li.selected').last().data('value'), 10);
        if(isNaN(ratingValue)) {
            $('.reviewForm .alert').html('Please select a rating');
            $('.reviewForm .alert').show()
            return false;
        }
    })

    $('.cancelOrder').click(function(e){
        if(!confirm('Are you sure you want to cancel the order?')) {
            return false;
            e.preventDefault();
        }
    })

    $('.pay').click(function(){
        $('.paymentForm').show()
        $('input[name="cardName"]').focus()
        if($(this).attr('data-initial') == 'true') {
            $('.panel-title').html('Payment for service');
            $('.aHours').html($(this).attr('data-hours'))
            $('.hide').hide()
            $('.updateText').html('Hours: ')
            $('.per').html($(this).attr('data-per'))
            $('input[name="_item"]').val($(this).attr('data-item'))

            $('.total').html('<?php echo config('app.currency'); ?>' + $(this).attr('data-amt'))
        } else {
            $('.hide').show()
            $('.updateText').html('Additional hours worked: ')
            $('.panel-title').html('Payment Invoice for ' + $(this).attr('data-order'));
            $('.aHours').html($(this).attr('data-hours'))
            $('.aP').html($(this).attr('data-additional-purchases'))
            $('.aPA').html($(this).attr('data-amt'))
            $('.per').html($(this).attr('data-per'))
            $('input[name="_invoice"]').val($(this).attr('data-invoice'))

            $('.total').html('<?php echo config('app.currency'); ?>' + $(this).attr('data-total'))
        }
        
        return false;
    })

    $('input[name="expiry"]').keypress(function(e){
        if(! /^\d*$/.test(e.key)) {
            return false;
        }

        if($(this).val().length >= 2 && e.keyCode !== 46 && e.keyCode !== 8) {
            if($(this).val().indexOf('/') === -1)
                $(this).val($(this).val().substr(0, 2) + '/' + $(this).val().substr(2))
        }

        if($(this).val().length >= 5)
            $(this).val($(this).val().substr(0, 5)) 
    })

    $('input[name="expiry"]').on('paste', function(e){
        return false;
    })

    if($('.alert').html().length)
        $('.pay').trigger('click')
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>