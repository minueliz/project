<?php $__env->startSection('title', '| Add New District'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Add District</div>

                <div class="card-body">
                  <!-- if there are creation errors, they will show here -->
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                      <?php echo e(Html::ul($errors->all())); ?>

                    </div>
                  <?php endif; ?>

                  <?php echo e(Form::open(array('url' => 'districts'))); ?>

                    <div class="lds-dual-ring"></div>
                    <fieldset>
                      <div class="form-group row">
                          <?php echo e(Form::label('district', 'District Name', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('district', Request::old('district'), array('class' => 'form-control'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

                        </div>
                      </div>
                    </fieldset>
                  <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>