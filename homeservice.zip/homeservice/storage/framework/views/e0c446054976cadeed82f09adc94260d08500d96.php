<?php $__env->startComponent('mail::message'); ?>
Dear <?php echo e($name); ?>,

User <b><?php echo e($service->order->user->name); ?></b> has paid for the order, #<b><a href="<?php echo e(URL::to('service-requests/' . $service->id)); ?>"><?php echo e($service->id); ?></a></b>. 
Find below the details,<br>
Date: <?php echo e(date('d-m-Y')); ?><br>
Service Date: <?php echo e(date('d-m-Y', strtotime($service->service_slot_from))); ?><br>
Service Slot: <?php echo e(date('H:i', strtotime($service->service_slot_from))); ?> - 
                            <?php echo e(date('H:i', strtotime($service->service_slot_to))); ?><br>
Admin commission: <?php echo config('app.currency'); ?><?php echo e(number_format($service->commision, 2)); ?><br>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>