<?php $__env->startSection('title', '| Edit Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Edit Service Slot</div>

                <div class="card-body">
                  <!-- if there are creation errors, they will show here -->
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                      <?php echo e(Html::ul($errors->all())); ?>

                    </div>
                  <?php endif; ?>
                  <div class="alert alert-warning dis-none"></div>

                  <?php echo e(Form::model($slot, array('route' => array('service-slots.update', $slot->id), 'method' => 'PUT', 'enctype' => 'multipart/form-data'))); ?>

                    <fieldset>
                      <div class="form-group row">
                          <?php echo e(Form::label('start', 'Start', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('start', 10, array('class' => 'form-control'))); ?> (Hour)
                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('interval', 'Interval', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('interval', 60, array('class' => 'form-control'))); ?> (In minutes)
                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('duration', 'Duration', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('duration', 120, array('class' => 'form-control'))); ?> (In minutes)
                          </div>
                      </div>
                      
                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          <?php echo e(Form::button('Preview', array('class' => 'btn btn-primary preview'))); ?>

                        </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4 slots"></div>
                      </div>
                    </fieldset>
                  <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://momentjs.com/downloads/moment-with-locales.js"></script>
<script type="text/javascript">
$(function(){
  $('input').keypress(function(e){
    if(! /^\d*$/.test(e.key)) {
      return false;
    }
  })
  $('.preview').click(function(){
    $('.slots').empty();
    $('.dis-none').hide()
    if(isNaN(parseInt($('input[name="start"]').val())) || (parseInt($('input[name="start"]').val()) <1 || parseInt($('input[name="start"]').val()) > 12)) {
      $('input[name="start"]').focus()
      $('.dis-none').html('Please enter valid start time between 1 and 12');
      $('.dis-none').show()
      return false;
    } else if(isNaN(parseInt($('input[name="interval"]').val()))  || (parseInt($('input[name="interval"]').val()) <1 || parseInt($('input[name="interval"]').val()) > 120)) {
      $('input[name="interval"]').focus()
      $('.dis-none').html('Please enter valid interval time between 1 and 120');
      $('.dis-none').show()
      return false;
    } else if(isNaN(parseInt($('input[name="duration"]').val())) || (parseInt($('input[name="duration"]').val()) <1 || parseInt($('input[name="duration"]').val()) > 180)) {
      $('input[name="duration"]').focus()
      $('.dis-none').html('Please enter valid duration time between 1 and 180');
      $('.dis-none').show()
      return false;
    }

    var start = moment.utc($('input[name="start"]').val(),'hh:mm A').format('hh:mm A');
    var interval = parseInt($('input[name="interval"]').val());
    var duration = parseInt($('input[name="duration"]').val());
    
    var append = '<b><u>Slots</u></b><br>';
    for(var i=0; i<4; i++) {
      var end = moment.utc(start,'hh:mm A').add(duration,'minutes').format('hh:mm A');
      append += (start + ' - ' + end) + '<br>';
      
      append += '<input type="hidden" name="slots[]" value="'+ start + ' - ' + end +'">';

      start = moment.utc(start,'hh:mm A').add((duration+interval),'minutes').format('hh:mm A');
    }
    $('.slots').html(append + '<br><input class="btn btn-primary" type="submit" value="Save">')
  }) 
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>