<?php $__env->startSection('title', '| User Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <div class="card">                
                <div class="card-body">
                  <?php if(session('success')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('success')); ?>

                      </div>
                  <?php endif; ?> 
                  <h4>Service request details</h4>
                    <div class="form-group row">
                        <?php echo e(Form::label('name', 'Customer', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e($serviceRequest->order->user->name); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <?php echo e(Form::label('addr', 'Order Date', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e(date('d-m-Y', strtotime($serviceRequest->created_at))); ?><br>
                        </div>
                    </div>

                    <div class="form-group row">
                        <?php echo e(Form::label('addr', 'Date', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e(date('d-m-Y', strtotime($serviceRequest->service_slot_from))); ?><br>
                        </div>
                    </div>

                    <div class="form-group row">
                        <?php echo e(Form::label('addr', 'Address', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo nl2br($serviceRequest->order->service_addr); ?><br>
                        </div>
                    </div>

                    <div class="form-group row">
                        <?php echo e(Form::label('addr', 'Phone', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                        <div class="col-md-4">
                          <?php echo e($serviceRequest->order->user->userinformation->phone); ?><br>
                          <?php if(!empty($serviceRequest->order->user->userinformation->phone)): ?>
                            <?php echo e($serviceRequest->order->user->userinformation->alt_phone); ?>

                          <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                          <?php echo e(Form::label('did', 'Category', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e($serviceRequest->worker->userinformation->category->category); ?>

                          </div>
                    </div>

                    <div class="form-group row">
                          <?php echo e(Form::label('did', 'Subcategory', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e($serviceRequest->serviceSubCat->category); ?>

                          </div>
                    </div>

                    <div class="form-group row">
                          <?php echo e(Form::label('did', 'Subcategory', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e($serviceRequest->serviceSubCat->category); ?>

                          </div>
                    </div>

                    <div class="form-group row">
                          <?php echo e(Form::label('did', 'Slot', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(date('H:i', strtotime($serviceRequest->service_slot_from))); ?> - 
                            <?php echo e(date('H:i', strtotime($serviceRequest->service_slot_to))); ?>

                          </div>
                    </div>

                    <div class="form-group row">
                          <?php echo e(Form::label('did', 'Description', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e($serviceRequest->description); ?> 
                          </div>
                    </div>

                    <div class="form-group row">
                          <?php echo e(Form::label('did', 'Image', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <a href="<?php echo e(URL::asset('images/serv')); ?>/<?php echo e($serviceRequest->img); ?>" target="_blank"><img class="w-100" src="<?php echo e(URL::asset('images/serv')); ?>/<?php echo e($serviceRequest->img); ?>"></a>
                          </div>
                    </div>

                    <div class="form-group row">
                          <?php echo e(Form::label('did', 'Commission', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo config('app.currency'); ?><?php echo e(number_format($serviceRequest->commision, 2)); ?>

                          </div>
                    </div>

                    <div class="form-group row">
                          <?php echo e(Form::label('did', 'Total', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo config('app.currency'); ?><?php echo e(number_format($serviceRequest->amount, 2)); ?>

                          </div>
                    </div>
                    <?php if(!is_null($serviceRequest->invoice)): ?>
                      <h4>Invoice details</h4>
                      <div class="form-group row">
                          <?php echo e(Form::label('did', 'Total', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo config('app.currency'); ?><?php echo e(number_format($serviceRequest->amount, 2)); ?>

                          </div>
                      </div>
                    <?php endif; ?>
                </div>
            </div>
          <?php if($serviceRequest->status == 0): ?>
            <div class="card mt-5">    
              <div class="card-body">                                
                  <?php if($errors->has('error')): ?>
                      <div class="alert alert-danger" id="error" tabindex='1'>
                          <?php echo e($errors->first('error')); ?>

                      </div>
                  <?php endif; ?>
                  <h4>Update and confirm schedule</h4>
                  <?php echo e(Form::open(array('url' => '/update-schedule/'.$serviceRequest->id, 'method' => 'put', 'class' => "reviewForm"))); ?>

                    <div class="row">
                      <div class="col-md-2">
                        <div class="form-group">
                          <span class="form-label">Date</span>
                          <?php echo e(Form::text('bDate', $bDate, array('class' => 'form-control required', 'id' => 'bDate', 'placeholder' => 'mm/dd/yyyy'))); ?>

                        </div>
                      </div>
                      <div style="width:85px" class="pr-3">
                        <div class="form-group">
                          <span class="form-label">From</span>
                          <?php echo Form::select('slotFrom', $hours, $_slotFrom, ['class' => 'form-control required']); ?>

                          <span class="select-arrow"></span>
                        </div>
                      </div>
                      <div style="width:85px">
                        <div class="form-group">
                          <span class="form-label">To</span>
                          <?php echo Form::select('slotTo', $hours, $_slotTo, ['class' => 'form-control required']); ?>

                          <span class="select-arrow"></span>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-btn">
                          <button class="submit-btn btn btn-primary mt-4">Confirm</button>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-btn">
                          <button class="submit-btn btn btn-danger mt-4" name="cancel" value="1">Cancel</button>
                        </div>
                      </div>
                    </div>
                  <?php echo e(Form::close()); ?>                
              </div>
            </div>
          <?php endif; ?>
        </div>        
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>" defer></script>
<script type="text/javascript">
$(function(){    
  if($( ".alert" ).length)
    $( ".alert" ).focus();

  $( "#bDate" ).datepicker({ 
                  dateFormat: 'dd-mm-yy',
                  minDate: '<?php echo e($bDate); ?>'
               });

  $('select[name="slotFrom"] option[value="<?php echo e(config('app.endH')); ?>"]').remove()
  $('select[name="slotFrom"]').click(function(){
    $('select[name="slotTo"] option').removeAttr('disabled')
    for (var i = <?php echo e(config('app.startH')); ?>; i <= $('select[name="slotFrom"]').val(); i++) {
      $('select[name="slotTo"] option[value="'+(i < 10 ? pad("0" + i, 2) : i)+'"]').attr('disabled', 'disabled')
    };
    $('select[name="slotTo"]').val(parseInt($('select[name="slotFrom"]').val()) < 9 ? pad("0" + (parseInt($('select[name="slotFrom"]').val()) + 1), 2) : parseInt($('select[name="slotFrom"]').val()) + 1).change()
  })

  function pad (str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
  }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>