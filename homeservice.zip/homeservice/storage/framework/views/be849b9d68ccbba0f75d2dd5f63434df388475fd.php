<?php $__env->startSection('title', '| Edit Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Edit Product</div>

                <div class="card-body">
                  <!-- if there are creation errors, they will show here -->
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                      <?php echo e(Html::ul($errors->all())); ?>

                    </div>
                  <?php endif; ?>

                  <?php echo e(Form::model($product, array('route' => array('products.update', $product->id), 'method' => 'PUT', 'enctype' => 'multipart/form-data'))); ?>

                    <fieldset>
                      <div class="form-group row">
                          <?php echo e(Form::label('name', 'Name', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('name', Request::old('name'), array('class' => 'form-control'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('description', 'Description', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::textarea('description', Request::old('description'), array('class' => 'form-control', 'rows' => '3'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('cat', 'Category', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo Form::select('cat', $categories, $product->product_category, ['class' => 'form-control m-bot15']); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('qty', 'Quantity', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('qty', (Request::old('qty')?Request::old('qty'):($newQty?($newQty + $product->qty):$product->qty)), array('class' => 'form-control', 'placeholder' => "Khumalo"))); ?>                            
                          </div>
                          <?php if($newQty): ?>
                            Old quantity: <?php echo e($product->qty); ?>

                          <?php endif; ?>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('amount', 'Amount', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('amount', Request::old('amount'), array('class' => 'form-control'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('image', 'Image', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::file('image', array('class' => $errors->has('image') ? 'form-control is-invalid' : 'form-control'))); ?>

                          </div>
                      </div>
                    <?php if(!empty($product->img)): ?>
                      <div class="form-group row offset-md-4">
                        <div class="col-md-4">
                          <img class="profilepic" src="<?php echo e(URL::asset('images/products')); ?>/<?php echo e($product->img); ?>">
                        </div>
                      </div>
                    <?php endif; ?>
                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

                        </div>
                      </div>
                    </fieldset>
                  <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>