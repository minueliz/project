<?php $__env->startSection('title', '| Add New Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Add product</div>

                <div class="card-body">
                  <!-- if there are creation errors, they will show here -->
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                      <?php echo e(Html::ul($errors->all())); ?>

                    </div>
                  <?php endif; ?>

                  <?php echo e(Form::open(array('url' => 'products', 'enctype' => 'multipart/form-data'))); ?>

                    <div class="lds-dual-ring"></div>
                    <fieldset>
                      <div class="form-group row">
                          <?php echo e(Form::label('name', 'Name', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('name', Request::old('name'), array('class' => 'form-control'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('description', 'Description', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::textarea('description', null, array('class' => 'form-control', 'rows' => '3'))); ?>

                          </div>
                      </div>

                      <div class="form-group row insertAfter">
                          <?php echo e(Form::label('cat', 'Category', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo Form::select('cat', $categories, null, ['class' => 'form-control m-bot15']); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('qty', 'Quantity', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('qty', Request::old('qty'), array('class' => 'form-control'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('amount', 'Amount', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('amount', Request::old('amount'), array('class' => 'form-control', 'placeholder' => "0.00"))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                            <?php echo e(Form::label('image', 'Image', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                            <div class="col-md-4">
                              <?php echo e(Form::file('image', array('class' => $errors->has('image') ? 'form-control is-invalid' : 'form-control'))); ?>

                            </div>
                      </div>
                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

                        </div>
                      </div>
                    </fieldset>
                  <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>