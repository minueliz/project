<?php $__env->startSection('title', '| Edit Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Edit Profile</div>

                <div class="card-body">
                  <!-- if there are creation errors, they will show here -->
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                      <?php echo e(Html::ul($errors->all())); ?>

                    </div>
                  <?php endif; ?>
                  <?php if(session('success')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('success')); ?>

                      </div>
                  <?php endif; ?>

                  <?php echo e(Form::model($userInfo, array('url' => array('edit-profile'), 'method' => 'POST', 'enctype' => 'multipart/form-data'))); ?>

                    <fieldset>

                      <div class="form-group row">
                          <?php echo e(Form::label('name', 'Name', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('name', $userInfo->user->name, array('class' => 'form-control', 'placeholder' => "Ayanda"))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('addr', 'Address', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::textarea('addr', Request::old('addr'), array('class' => 'form-control', 'rows' => '3'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                            <?php echo e(Form::label('did', 'District', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                            <div class="col-md-4">
                              <?php echo Form::select('did', $districts, $userInfo->district_id, ['class' => $errors->has('did') ? 'form-control is-invalid' : 'form-control']); ?>

                            </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('pin_code', 'Pin code', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('pin_code', Request::old('pin_code'), array('class' => 'form-control'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('phone', 'Phone', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('phone', Request::old('phone'), array('class' => 'form-control', 'placeholder' => "0764344899"))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('alt_phone', 'Alternate phone', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('alt_phone', Request::old('alt_phone'), array('class' => 'form-control', 'placeholder' => "0821234567"))); ?>

                          </div>
                      </div>
                    <?php if($worker): ?>
                      <div class="form-group row">
                          <?php echo e(Form::label('scat', 'Service category', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo Form::select('scat', $categories, $userInfo->service_category, ['class' => $errors->has('scat') ? 'form-control is-invalid' : 'form-control']); ?>

                          </div>
                      </div>
                    <?php endif; ?>
                      <div class="form-group row">
                            <?php echo e(Form::label('sec_q', 'Security question', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                            <div class="col-md-4">
                              <?php echo Form::select('sec_q', $sec_qs, $userInfo->sec_q, ['class' => $errors->has('sec_q') ? 'form-control is-invalid' : 'form-control']); ?>

                            </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('sec_a', 'Answer', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::text('sec_a', Request::old('sec_a'), array('class' => 'form-control'))); ?>

                          </div>
                      </div>

                      <div class="form-group row">
                          <?php echo e(Form::label('image', 'Profile picture', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                          <div class="col-md-4">
                            <?php echo e(Form::file('image', array('class' => $errors->has('image') ? 'form-control is-invalid' : 'form-control'))); ?>

                          </div>
                      </div>
                    <?php if(!empty($userInfo->img)): ?>
                      <div class="form-group row offset-md-4">
                        <div class="col-md-4">
                          <img class="profilepic" src="<?php echo e(URL::asset('images/profile')); ?>/<?php echo e($userInfo->img); ?>">
                        </div>
                      </div>
                    <?php endif; ?>
                      <?php if($worker): ?>
                            <div class="form-group row">
                                <?php echo e(Form::label('exp_proof', 'Experience proof', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                                <div class="col-md-4">
                                  <?php echo e(Form::file('exp_proof', array('class' => $errors->has('exp_proof') ? 'form-control is-invalid' : 'form-control'))); ?>

                                </div>
                            </div>
                          
                            <div class="form-group row offset-md-4">
                              <div class="col-md-4">
                                <img class="profilepic" src="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($userInfo->exp_proof); ?>">
                              </div>
                            </div>
                          
                            <div class="form-group row">
                                <?php echo e(Form::label('id_proof', 'Identity proof', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                                <div class="col-md-4">
                                  <?php echo e(Form::file('id_proof', array('class' => $errors->has('id_proof') ? 'form-control is-invalid' : 'form-control'))); ?>

                                </div>
                            </div>
                          
                            <div class="form-group row offset-md-4">
                              <div class="col-md-4">
                                <img class="profilepic" src="<?php echo e(URL::asset('images/proofs')); ?>/<?php echo e($userInfo->id_proof); ?>">
                              </div>
                            </div>

                            <div class="form-group row">
                                <?php echo e(Form::label('per_hour_amount', 'Per hour amount', array('class' => 'col-md-4 control-label text-md-right'))); ?>

                                <div class="col-md-4">
                                  <?php echo e(Form::number('per_hour_amount', Request::old('per_hour_amount'), array('class' => 'form-control', 'min' => 1, 'max' => 999))); ?>

                                </div>
                            </div>
                      <?php endif; ?>

                      <div class="form-group row">
                        <div class="col-md-4 offset-md-4">
                          <?php echo e(Form::submit('Save', array('class' => 'btn btn-primary'))); ?>

                        </div>
                      </div>
                    </fieldset>
                  <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>